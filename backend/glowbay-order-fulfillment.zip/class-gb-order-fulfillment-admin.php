<?php
/**
 * GlowBay Order Fulfillment & Payment Decision Admin Hub (v2.0.0)
 * Master Blueprint Engine: Payment Verification, 1-Click Approve/Reject, Fulfillment Stages & Filter Tabs.
 */

if (!defined('ABSPATH')) {
    exit;
}

class GB_Order_Fulfillment_Admin {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        // Register custom order statuses
        add_action('init', [$this, 'register_custom_order_statuses']);
        add_filter('wc_order_statuses', [$this, 'add_custom_statuses_to_wc']);

        // Admin Order Meta Box
        add_action('add_meta_boxes', [$this, 'register_order_fulfillment_metabox']);

        // Admin Actions (Approve, Reject, Update Stage)
        add_action('admin_post_gb_approve_payment', [$this, 'handle_approve_payment']);
        add_action('admin_post_gb_reject_payment', [$this, 'handle_reject_payment']);
        add_action('admin_post_gb_update_fulfillment_stage', [$this, 'handle_update_fulfillment_stage']);

        // Admin Order List Custom Filter Bar
        add_action('restrict_manage_posts', [$this, 'render_admin_order_status_filter']);
        add_filter('request', [$this, 'filter_orders_by_fulfillment_status']);

        // 3-Hour Unpaid Order Expiration Cron
        add_action('gb_check_unpaid_order_deadline_event', [$this, 'cron_cancel_expired_orders']);
        if (!wp_next_scheduled('gb_check_unpaid_order_deadline_event')) {
            wp_schedule_event(time(), 'hourly', 'gb_check_unpaid_order_deadline_event');
        }

        // Frontend Desktop & Mobile Web Tracking Integration
        add_action('woocommerce_order_details_after_order_table', [$this, 'render_woocommerce_order_fulfillment']);
        add_shortcode('gb_order_tracking', [$this, 'render_frontend_order_tracking']);
    }

    /**
     * Register Canonical Custom Order Statuses
     */
    public function register_custom_order_statuses() {
        register_post_status('wc-to-pay', [
            'label'                     => _x('To Pay (Awaiting Payment)', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('To Pay <span class="count">(%s)</span>', 'To Pay <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);

        register_post_status('wc-payment-review', [
            'label'                     => _x('Payment Under Review', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Payment Review <span class="count">(%s)</span>', 'Payment Review <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);

        register_post_status('wc-to-ship', [
            'label'                     => _x('To Ship (Sourcing & Packing)', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('To Ship <span class="count">(%s)</span>', 'To Ship <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);

        register_post_status('wc-in-transit', [
            'label'                     => _x('In Transit to Dhaka', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('In Transit <span class="count">(%s)</span>', 'In Transit <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);

        register_post_status('wc-arrived-dhaka', [
            'label'                     => _x('Arrived in Dhaka', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Arrived in Dhaka <span class="count">(%s)</span>', 'Arrived in Dhaka <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);

        register_post_status('wc-return-review', [
            'label'                     => _x('Return Under Review', 'Order status', 'glowbay-app-api'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Return Under Review <span class="count">(%s)</span>', 'Return Under Review <span class="count">(%s)</span>', 'glowbay-app-api'),
        ]);
    }

    public function add_custom_statuses_to_wc($order_statuses) {
        $new_statuses = [];
        foreach ($order_statuses as $key => $status) {
            $new_statuses[$key] = $status;
            if ('wc-processing' === $key) {
                $new_statuses['wc-to-pay']          = _x('To Pay (Awaiting Payment)', 'Order status', 'glowbay-app-api');
                $new_statuses['wc-payment-review']  = _x('Payment Under Review', 'Order status', 'glowbay-app-api');
                $new_statuses['wc-to-ship']         = _x('To Ship (Sourcing & Packing)', 'Order status', 'glowbay-app-api');
                $new_statuses['wc-in-transit']      = _x('In Transit to Dhaka', 'Order status', 'glowbay-app-api');
                $new_statuses['wc-arrived-dhaka']   = _x('Arrived in Dhaka', 'Order status', 'glowbay-app-api');
                $new_statuses['wc-return-review']   = _x('Return Under Review', 'Order status', 'glowbay-app-api');
            }
        }
        return $new_statuses;
    }

    /**
     * Register Meta Box in WooCommerce Order Edit Screen
     */
    public function register_order_fulfillment_metabox() {
        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') &&
                  wc_get_container()->get(\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class)->custom_orders_table_usage_is_enabled()
                  ? wc_get_page_screen_id('shop-order')
                  : 'shop_order';

        add_meta_box(
            'gb_fulfillment_engine_box',
            '⚡ GlowBay Master Fulfillment & Payment Decision Hub',
            [$this, 'render_order_fulfillment_metabox'],
            $screen,
            'normal',
            'high'
        );
    }

    /**
     * Render Admin Meta Box HTML
     */
    public function render_order_fulfillment_metabox($post_or_order_object) {
        $order = ($post_or_order_object instanceof WC_Order) ? $post_or_order_object : wc_get_order($post_or_order_object->ID);
        if (!$order) return;

        $order_id        = $order->get_id();
        $status          = $order->get_status();
        $method          = $order->get_payment_method();
        $sender_num      = $order->get_meta('_gb_sender_number') ?: $order->get_meta('_billing_sender_number');
        $trx_id          = $order->get_meta('_gb_trx_id') ?: $order->get_meta('_transaction_id') ?: $order->get_transaction_id();
        $receipt_url     = $order->get_meta('_gb_receipt_url') ?: $order->get_meta('_gb_bangla_qr_receipt');
        $payment_status  = $order->get_meta('_gb_payment_status') ?: ($trx_id ? 'submitted' : 'pending');
        $rejection_reason= $order->get_meta('_gb_payment_rejection_reason');
        $fulfillment_stg = $order->get_meta('_gb_fulfillment_stage') ?: 'pending';
        $created_time    = $order->get_date_created();
        $deadline_ts     = $created_time ? ($created_time->getTimestamp() + (3 * 3600)) : 0;
        $now             = time();
        $is_expired      = ($deadline_ts > 0 && $now > $deadline_ts && empty($trx_id) && !in_array($status, ['completed', 'processing', 'cancelled']));

        wp_nonce_field('gb_admin_fulfillment_action', 'gb_admin_fulfillment_nonce');
        ?>
        <style>
            .gb-f-wrap { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            .gb-f-grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 16px; margin-top: 10px; }
            .gb-f-card { background: #f8fafc; border: 1.5px solid #e2e8f0; border-radius: 12px; padding: 14px 18px; }
            .gb-f-card h4 { margin: 0 0 10px 0; font-size: 14px; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 6px; }
            .gb-f-badge { display: inline-block; padding: 3px 8px; border-radius: 999px; font-size: 11px; font-weight: 800; text-transform: uppercase; }
            .gb-f-badge.submitted { background: #dbeafe; color: #1e40af; }
            .gb-f-badge.review { background: #fef3c7; color: #92400e; }
            .gb-f-badge.approved { background: #dcfce7; color: #166534; }
            .gb-f-badge.rejected { background: #fee2e2; color: #991b1b; }
            .gb-f-badge.expired { background: #f1f5f9; color: #64748b; }
            .gb-f-btn-group { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
            .gb-btn-act { padding: 7px 14px; border-radius: 8px; font-weight: 700; font-size: 12px; cursor: pointer; text-decoration: none !important; display: inline-flex; align-items: center; gap: 5px; border: none; }
            .gb-btn-approve { background: #10b981; color: #fff !important; }
            .gb-btn-approve:hover { background: #059669; }
            .gb-btn-reject { background: #ef4444; color: #fff !important; }
            .gb-btn-reject:hover { background: #dc2626; }
            .gb-btn-stage { background: #3b82f6; color: #fff !important; }
            .gb-btn-stage:hover { background: #2563eb; }
        </style>

        <div class="gb-f-wrap">
            <div class="gb-f-grid">
                <!-- 1. Payment Verification Card -->
                <div class="gb-f-card">
                    <h4>💳 Payment Verification & Decision Engine</h4>
                    <p style="margin: 4px 0 8px 0; font-size: 12px; color: #64748b;">
                        Method: <strong><?php echo esc_html(strtoupper(str_replace('glowbay_', '', $method))); ?></strong> | 
                        Status: <span class="gb-f-badge <?php echo esc_attr($payment_status); ?>"><?php echo esc_html(str_replace('_', ' ', $payment_status)); ?></span>
                    </p>

                    <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
                        <tr><td style="color:#64748b; padding:3px 0; width:110px;">Sender Phone:</td><td><strong><?php echo esc_html($sender_num ?: 'Not Provided'); ?></strong></td></tr>
                        <tr><td style="color:#64748b; padding:3px 0;">Transaction ID:</td><td><strong style="color:#0284c7;"><?php echo esc_html($trx_id ?: 'Not Provided'); ?></strong></td></tr>
                        <?php if ($receipt_url) : ?>
                            <tr><td style="color:#64748b; padding:3px 0;">Payment Slip:</td><td><a href="<?php echo esc_url($receipt_url); ?>" target="_blank" style="color:#2563eb; font-weight:700;">🔍 View Receipt Image</a></td></tr>
                        <?php endif; ?>
                        <?php if ($rejection_reason) : ?>
                            <tr><td style="color:#ef4444; padding:3px 0;">Rejection Reason:</td><td style="color:#b91c1c; font-weight:700;"><?php echo esc_html($rejection_reason); ?></td></tr>
                        <?php endif; ?>
                    </table>

                    <div class="gb-f-btn-group">
                        <!-- Approve Button -->
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                            <input type="hidden" name="action" value="gb_approve_payment">
                            <input type="hidden" name="order_id" value="<?php echo esc_attr($order_id); ?>">
                            <?php wp_nonce_field('gb_approve_payment_nonce'); ?>
                            <button type="submit" class="gb-btn-act gb-btn-approve" onclick="return confirm('Approve payment for Order #<?php echo $order_id; ?>? Order will automatically move to To Ship.');">
                                ✓ Approve Payment
                            </button>
                        </form>

                        <!-- Reject Button with Reason Prompt -->
                        <button type="button" class="gb-btn-act gb-btn-reject" onclick="promptRejectPayment(<?php echo $order_id; ?>)">
                            ✕ Reject (Give Reason)
                        </button>
                    </div>
                </div>

                <!-- 2. Internal Fulfillment Stages Card -->
                <div class="gb-f-card">
                    <h4>📦 Internal Fulfillment Stages (To Ship)</h4>
                    <p style="margin: 4px 0 8px 0; font-size: 12px; color: #64748b;">
                        Current Stage: <strong style="color: #2563eb; text-transform: uppercase;"><?php echo esc_html(str_replace('_', ' ', $fulfillment_stg)); ?></strong>
                    </p>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="gb_update_fulfillment_stage">
                        <input type="hidden" name="order_id" value="<?php echo esc_attr($order_id); ?>">
                        <?php wp_nonce_field('gb_stage_nonce'); ?>
                        
                        <select name="fulfillment_stage" style="width:100%; font-size:12px; padding:4px; border-radius:6px; margin-bottom:8px;">
                            <option value="sourcing" <?php selected($fulfillment_stg, 'sourcing'); ?>>1. Product Sourcing (Malaysia)</option>
                            <option value="purchasing" <?php selected($fulfillment_stg, 'purchasing'); ?>>2. Product Being Purchased</option>
                            <option value="quality_check" <?php selected($fulfillment_stg, 'quality_check'); ?>>3. Quality Check & Verification</option>
                            <option value="packing" <?php selected($fulfillment_stg, 'packing'); ?>>4. Order Being Packed</option>
                            <option value="packing_list_ready" <?php selected($fulfillment_stg, 'packing_list_ready'); ?>>5. Packing List Ready (Awaiting KL Scan)</option>
                        </select>
                        <button type="submit" class="gb-btn-act gb-btn-stage">Update Stage</button>
                    </form>
                </div>
            </div>
        </div>

        <script>
            function promptRejectPayment(orderId) {
                var reason = prompt("Enter payment rejection reason (customer will see this to correct TrxID):", "TrxID not matched with bank account");
                if (reason && reason.trim().length > 0) {
                    var form = document.createElement('form');
                    form.method = 'POST';
                    form.action = '<?php echo esc_url(admin_url('admin-post.php')); ?>';
                    
                    var act = document.createElement('input'); act.type='hidden'; act.name='action'; act.value='gb_reject_payment'; form.appendChild(act);
                    var oid = document.createElement('input'); oid.type='hidden'; oid.name='order_id'; oid.value=orderId; form.appendChild(oid);
                    var rsn = document.createElement('input'); rsn.type='hidden'; rsn.name='rejection_reason'; rsn.value=reason; form.appendChild(rsn);
                    var nce = document.createElement('input'); nce.type='hidden'; nce.name='_wpnonce'; nce.value='<?php echo wp_create_nonce('gb_reject_payment_nonce'); ?>'; form.appendChild(nce);
                    
                    document.body.appendChild(form);
                    form.submit();
                }
            }
        </script>
        <?php
    }

    /**
     * Action: Approve Payment
     */
    public function handle_approve_payment() {
        if (!current_user_can('manage_woocommerce')) wp_die('Access denied.');
        check_admin_referer('gb_approve_payment_nonce');

        $order_id = intval($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_meta_data('_gb_payment_status', 'approved');
            $order->update_meta_data('_gb_payment_approved_time', wp_date('d M Y, h:i A'));
            $order->update_meta_data('_gb_fulfillment_stage', 'sourcing');
            
            // Automatic Transition to To Ship
            $order->set_status('wc-to-ship', 'Payment Verified & Approved by Admin. Order moved to To Ship (Sourcing).');
            $order->save();
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('post.php?post=' . $order_id . '&action=edit'));
        exit;
    }

    /**
     * Action: Reject Payment
     */
    public function handle_reject_payment() {
        if (!current_user_can('manage_woocommerce')) wp_die('Access denied.');
        check_admin_referer('gb_reject_payment_nonce');

        $order_id = intval($_POST['order_id'] ?? 0);
        $reason = sanitize_text_field($_POST['rejection_reason'] ?? 'Payment verification unsuccessful');
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_meta_data('_gb_payment_status', 'rejected');
            $order->update_meta_data('_gb_payment_rejection_reason', $reason);
            $order->set_status('wc-to-pay', "Payment Rejected by Admin. Reason: $reason. Customer notified to resubmit.");
            $order->save();
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('post.php?post=' . $order_id . '&action=edit'));
        exit;
    }

    /**
     * Action: Update Fulfillment Stage
     */
    public function handle_update_fulfillment_stage() {
        if (!current_user_can('manage_woocommerce')) wp_die('Access denied.');
        check_admin_referer('gb_stage_nonce');

        $order_id = intval($_POST['order_id'] ?? 0);
        $stage = sanitize_text_field($_POST['fulfillment_stage'] ?? 'sourcing');
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_meta_data('_gb_fulfillment_stage', $stage);
            $order->add_order_note("Fulfillment Stage updated to: " . strtoupper(str_replace('_', ' ', $stage)));
            $order->save();
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('post.php?post=' . $order_id . '&action=edit'));
        exit;
    }

    /**
     * Render Admin Order Status Filter on Shop Order List
     */
    public function render_admin_order_status_filter($post_type) {
        if ($post_type !== 'shop_order') return;
        $current = sanitize_text_field($_GET['gb_fulfillment_status'] ?? '');
        ?>
        <select name="gb_fulfillment_status" id="gb_fulfillment_status">
            <option value="">All Fulfillment Funnels</option>
            <option value="to-pay" <?php selected($current, 'to-pay'); ?>>Funnel: To Pay</option>
            <option value="payment-review" <?php selected($current, 'payment-review'); ?>>Funnel: Payment Under Review</option>
            <option value="to-ship" <?php selected($current, 'to-ship'); ?>>Funnel: To Ship (Sourcing & Packing)</option>
            <option value="in-transit" <?php selected($current, 'in-transit'); ?>>Funnel: In Transit to Dhaka</option>
            <option value="arrived-dhaka" <?php selected($current, 'arrived-dhaka'); ?>>Funnel: Arrived in Dhaka</option>
            <option value="return-review" <?php selected($current, 'return-review'); ?>>Funnel: Returns</option>
        </select>
        <?php
    }

    public function filter_orders_by_fulfillment_status($vars) {
        global $typenow;
        if ($typenow === 'shop_order' && !empty($_GET['gb_fulfillment_status'])) {
            $vars['post_status'] = 'wc-' . sanitize_text_field($_GET['gb_fulfillment_status']);
        }
        return $vars;
    }

    /**
     * Cron: Cancel orders older than 3 hours with no payment submitted
     */
    public function cron_cancel_expired_orders() {
        $three_hours_ago = time() - (3 * 3600);

        $orders = wc_get_orders([
            'status'        => ['wc-pending', 'wc-to-pay', 'pending'],
            'date_created'  => '<' . $three_hours_ago,
            'limit'         => 50,
        ]);

        foreach ($orders as $order) {
            $trx_id = $order->get_meta('_gb_trx_id') ?: $order->get_transaction_id();
            if (empty($trx_id)) {
                $order->update_status('cancelled', 'Payment Time Expired (3-Hour Deadline). Order automatically cancelled by server.');
                // Restock inventory
                if (function_exists('wc_restock_refunded_items')) {
                    foreach ($order->get_items() as $item) {
                        $product = $item->get_product();
                        if ($product && $product->managing_stock()) {
                            wc_update_product_stock($product, $item->get_quantity(), 'increase');
                        }
                    }
                }
            }
        }
    }

    /**
     * Frontend WooCommerce Order Details Fulfillment Card (Desktop & Mobile Web)
     */
    public function render_woocommerce_order_fulfillment($order) {
        if (!$order) return;
        $order_id = $order->get_id();
        echo $this->get_fulfillment_html($order_id);
    }

    /**
     * Shortcode [gb_order_tracking id="123"]
     */
    public function render_frontend_order_tracking($atts) {
        $atts = shortcode_atts([
            'id' => 0,
        ], $atts, 'gb_order_tracking');

        $order_id = absint($atts['id']);
        if (!$order_id && isset($_GET['order_id'])) {
            $order_id = absint($_GET['order_id']);
        }
        if (!$order_id) {
            return '<div style="padding:20px; text-align:center; color:#64748b; font-family:sans-serif;">অর্ডার ট্র্যাকিং দেখতে অনুগ্রহ করে অর্ডার নম্বর দিন।</div>';
        }
        return $this->get_fulfillment_html($order_id);
    }

    /**
     * Generate Luxury Responsive HTML for Frontend (Desktop & Mobile Web)
     */
    public function get_fulfillment_html($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return '';

        $stage = (int) get_post_meta($order_id, '_gb_tracking_stage', true);
        if ($stage < 1) $stage = 1;
        $payment_status = get_post_meta($order_id, '_gb_payment_status', true) ?: 'pending';
        $rejection_reason = get_post_meta($order_id, '_gb_payment_rejection_reason', true) ?: '';
        $courier_code = get_post_meta($order_id, '_gb_courier_code', true) ?: get_post_meta($order_id, 'courier_tracking_code', true);
        $return_status = get_post_meta($order_id, '_gb_return_status', true) ?: '';
        $date_created_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time();
        $deadline_ts = $date_created_ts + (3 * 3600);
        $remaining_seconds = max(0, $deadline_ts - time());
        $is_cancelled = $order->has_status(['cancelled', 'failed']);
        $can_cancel = ($stage < 3 && !$is_cancelled);
        $can_return = ($order->has_status('completed'));

        ob_start();
        ?>
        <div class="gb-fulfillment-wrap" style="margin:24px 0; background:#ffffff; border:1px solid #e2e8f0; border-radius:18px; padding:24px; box-shadow:0 4px 20px rgba(15,23,42,0.04); font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">
            <!-- Header -->
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; border-bottom:1px solid #f1f5f9; padding-bottom:16px; margin-bottom:20px;">
                <div>
                    <h3 style="margin:0; font-size:18px; font-weight:800; color:#0f172a;">লাইভ অর্ডার ট্র্যাকিং ও ডেলিভারি স্ট্যাটাস</h3>
                    <p style="margin:4px 0 0; font-size:13px; color:#64748b; font-weight:600;">অর্ডার #<?php echo esc_html($order_id); ?> • গ্লোবে প্রি-অর্ডার ফুলফিলমেন্ট</p>
                </div>
                <div>
                    <span style="display:inline-block; padding:6px 14px; background:#eff6ff; color:#2563eb; font-weight:800; font-size:12px; border-radius:30px; border:1px solid #bfdbfe;">
                        <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?>
                    </span>
                </div>
            </div>

            <!-- 3-Hour Unpaid Countdown Alert -->
            <?php if (!$is_cancelled && $payment_status !== 'approved' && $remaining_seconds > 0): ?>
                <div style="background:#fffbeb; border:1.5px solid #fde68a; border-radius:12px; padding:14px 18px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="font-size:20px;">⏳</span>
                        <div>
                            <strong style="color:#92400e; font-size:14px;">অগ্রিম পেমেন্টের সময়সীমা (৩ ঘণ্টা)</strong>
                            <div style="font-size:12px; color:#b45309;">নির্ধারিত সময়ের মধ্যে পেমেন্ট TrxID না দিলে অর্ডারটি স্বয়ংক্রিয়ভাবে বাতিল হয়ে যাবে।</div>
                        </div>
                    </div>
                    <div id="gb-countdown-<?php echo esc_attr($order_id); ?>" style="background:#92400e; color:#ffffff; font-weight:800; font-family:monospace; font-size:15px; padding:6px 14px; border-radius:8px; letter-spacing:1px;">
                        <?php echo sprintf('%02d:%02d:%02d', floor($remaining_seconds/3600), floor(($remaining_seconds%3600)/60), $remaining_seconds%60); ?>
                    </div>
                </div>
                <script>
                    (function(){
                        var sec = <?php echo (int) $remaining_seconds; ?>;
                        var el = document.getElementById("gb-countdown-<?php echo esc_attr($order_id); ?>");
                        if (!el) return;
                        var timer = setInterval(function(){
                            if (sec <= 0) {
                                clearInterval(timer);
                                el.innerText = "সময় উত্তীর্ণ";
                                return;
                            }
                            sec--;
                            var h = Math.floor(sec / 3600);
                            var m = Math.floor((sec % 3600) / 60);
                            var s = sec % 60;
                            el.innerText = (h<10?'0'+h:h)+':'+(m<10?'0'+m:m)+':'+(s<10?'0'+s:s);
                        }, 1000);
                    })();
                </script>
            <?php endif; ?>

            <!-- Payment Under Review or Rejection Alert -->
            <?php if ($payment_status === 'under_review'): ?>
                <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:12px; padding:14px 18px; margin-bottom:20px; display:flex; align-items:center; gap:12px;">
                    <span style="font-size:20px;">🔍</span>
                    <div>
                        <strong style="color:#1e40af; font-size:14px;">পেমেন্ট ভেরিফিকেশন চলছে</strong>
                        <div style="font-size:12px; color:#3b82f6;">আপনার জমা দেওয়া TrxID অ্যাডমিন প্যানেলে যাচাই করা হচ্ছে। খুব শীঘ্রই অর্ডারটি কনফার্ম হবে।</div>
                    </div>
                </div>
            <?php elseif ($payment_status === 'rejected'): ?>
                <div style="background:#fef2f2; border:1.5px solid #fecaca; border-radius:12px; padding:16px; margin-bottom:20px;">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                        <span style="font-size:20px;">❌</span>
                        <div>
                            <strong style="color:#991b1b; font-size:14px;">পেমেন্ট ভেরিফিকেশন ব্যর্থ হয়েছে</strong>
                            <?php if (!empty($rejection_reason)): ?>
                                <div style="font-size:12.5px; color:#b91c1c;">কারণ: <?php echo esc_html($rejection_reason); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="font-size:12px; color:#7f1d1d; margin:0 0 10px;">অনুগ্রহ করে সঠিক Transaction ID ও প্রেরক নম্বর পুনরায় জমা দিন।</p>
                    <form method="post" action="<?php echo esc_url(rest_url('glowbay-app/v1/orders/' . $order_id . '/resubmit-payment')); ?>" style="display:flex; gap:8px; flex-wrap:wrap;">
                        <input type="text" name="trx_id" placeholder="সঠিক TrxID লিখুন *" required style="padding:8px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; flex:1; min-width:180px;">
                        <input type="text" name="sender_number" placeholder="প্রেরক নম্বর" style="padding:8px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; flex:1; min-width:140px;">
                        <button type="submit" style="background:#e11d48; color:#fff; border:none; border-radius:8px; padding:8px 18px; font-weight:700; font-size:13px; cursor:pointer;">আপডেট করুন</button>
                    </form>
                </div>
            <?php endif; ?>

            <?php if ($is_cancelled): ?>
                <!-- Lazada-Style Order Cancellation Notice Card -->
                <div style="background:#fff1f2; border:1.5px solid #fecdd3; border-radius:14px; padding:20px; margin:20px 0; text-align:center;">
                    <div style="font-size:36px; margin-bottom:8px;">🛑</div>
                    <h4 style="margin:0 0 6px; font-size:16px; font-weight:800; color:#9f1239;">অর্ডারটি বাতিল করা হয়েছে (Order Cancelled)</h4>
                    <p style="margin:0 0 12px; font-size:13px; color:#be123c; line-height:1.5;">
                        এই অর্ডারটির প্রসেসিং ও লজিস্টিক ট্রানজিট কার্যক্রম বাতিল করা হয়েছে। কোনো প্রকার এয়ার কার্গো বা লোকাল কুরিয়ার ট্র্যাকিং প্রযোজ্য নয়।
                    </p>
                    <div style="display:inline-block; background:#ffffff; border:1px solid #fecaca; border-radius:8px; padding:6px 14px; font-size:12px; font-weight:700; color:#991b1b;">
                        অর্ডার আইডি: #<?php echo esc_html($order_id); ?> • স্ট্যাটাস: বাতিল (Deactivated)
                    </div>
                </div>
            <?php else: ?>
                <!-- 5-Stage Cross-Border Progress Steps -->
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:12px; margin:24px 0;">
                    <?php
                    $steps = [
                        1 => ['title' => 'অর্ডার প্লেসড', 'desc' => 'কনফার্মেশন সম্পন্ন', 'icon' => '📝'],
                        2 => ['title' => 'সোর্সিং ও প্যাকিং', 'desc' => 'কুয়ালালামপুর ওয়্যারহাউস', 'icon' => '📦'],
                        3 => ['title' => 'শিপমেন্টে প্রেরিত', 'desc' => 'এয়ার কার্গো ট্রানজিট', 'icon' => '✈️'],
                        4 => ['title' => 'ঢাকা হাবে পৌঁছেছে', 'desc' => 'সর্টিং ও কিউসি চেক', 'icon' => '🏢'],
                        5 => ['title' => 'ডেলিভারি সম্পন্ন', 'desc' => 'রাইডারের মাধ্যমে হস্তান্তরিত', 'icon' => '✅'],
                    ];
                    foreach ($steps as $st_num => $st_info):
                        $is_done = ($stage >= $st_num);
                        $is_active = ($stage == $st_num);
                    ?>
                        <div style="background:<?php echo $is_active ? '#fff1f2' : ($is_done ? '#f0fdf4' : '#f8fafc'); ?>; border:1.5px solid <?php echo $is_active ? '#e11d48' : ($is_done ? '#86efac' : '#e2e8f0'); ?>; border-radius:14px; padding:14px; text-align:center;">
                            <div style="font-size:24px; margin-bottom:6px;"><?php echo $st_info['icon']; ?></div>
                            <div style="font-size:13px; font-weight:800; color:<?php echo $is_active ? '#9f1239' : ($is_done ? '#166534' : '#64748b'); ?>;">
                                <?php echo esc_html($st_info['title']); ?>
                            </div>
                            <div style="font-size:11px; color:#64748b; margin-top:2px;">
                                <?php echo esc_html($st_info['desc']); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Steadfast Courier Integration Info -->
                <?php if (!empty($courier_code)): ?>
                    <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:14px 18px; margin-top:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <div>
                            <strong style="color:#0f172a; font-size:13.5px;">স্টেডফাস্ট কুরিয়ার ট্র্যাকিং কোড:</strong>
                            <span style="font-family:monospace; font-weight:800; color:#e11d48; margin-left:6px; font-size:14px;"><?php echo esc_html($courier_code); ?></span>
                        </div>
                        <a href="https://steadfast.com.bd/t/<?php echo esc_attr($courier_code); ?>" target="_blank" rel="noopener" style="display:inline-block; background:#0f172a; color:#ffffff; padding:6px 14px; border-radius:8px; text-decoration:none; font-size:12px; font-weight:700;">
                            লাইভ কুরিয়ার ট্র্যাক ↗
                        </a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Action Buttons: Cancel Order & Return Request -->
            <?php if ($can_cancel || $can_return): ?>
                <div style="margin-top:20px; padding-top:16px; border-top:1px solid #f1f5f9; display:flex; gap:12px; flex-wrap:wrap;">
                    <?php if ($can_cancel): ?>
                        <button type="button" onclick="if(confirm('আপনি কি নিশ্চিত যে অর্ডারটি বাতিল করতে চান? সংরক্ষিত স্টক তাৎক্ষণিকভাবে রিলিজ হবে।')) { document.getElementById('gb-cancel-form-<?php echo esc_attr($order_id); ?>').submit(); }" style="background:#fee2e2; color:#b91c1c; border:1px solid #fecaca; border-radius:8px; padding:8px 16px; font-weight:700; font-size:13px; cursor:pointer;">
                            অর্ডার বাতিল করুন (Instant Restock)
                        </button>
                        <form id="gb-cancel-form-<?php echo esc_attr($order_id); ?>" method="post" action="<?php echo esc_url(rest_url('glowbay-app/v1/orders/' . $order_id . '/cancel')); ?>" style="display:none;">
                            <input type="hidden" name="reason" value="ওয়েবসাইট ইউজার দ্বারা বাতিল">
                        </form>
                    <?php endif; ?>

                    <?php if ($can_return): ?>
                        <button type="button" onclick="var r = prompt('রিটার্নের কারণ লিখুন (৭ দিনের গ্যারান্টি পলিসি):'); if(r){ document.getElementById('gb-return-reason-<?php echo esc_attr($order_id); ?>').value=r; document.getElementById('gb-return-form-<?php echo esc_attr($order_id); ?>').submit(); }" style="background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; border-radius:8px; padding:8px 16px; font-weight:700; font-size:13px; cursor:pointer;">
                            ৭ দিনের রিটার্ন / রিফান্ড আবেদন
                        </button>
                        <form id="gb-return-form-<?php echo esc_attr($order_id); ?>" method="post" action="<?php echo esc_url(rest_url('glowbay-app/v1/orders/' . $order_id . '/request-return')); ?>" style="display:none;">
                            <input type="hidden" id="gb-return-reason-<?php echo esc_attr($order_id); ?>" name="reason" value="">
                        </form>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
}

GB_Order_Fulfillment_Admin::instance();
