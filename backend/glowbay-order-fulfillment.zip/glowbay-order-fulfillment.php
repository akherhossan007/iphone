<?php
/**
 * Plugin Name: GlowBay Order Fulfillment & Payment Decision Hub
 * Plugin URI: https://glowbaybd.com
 * Description: Master Blueprint Engine: 5-Funnel Customer Order Tracking, 14-Stage Admin Filter Bar, 1-Click Payment Approval/Rejection, 3-Hour Unpaid Deadline Cron, and Instant Restock Engine.
 * Version: 2.0.0
 * Author: GlowBay Engineering
 * Text Domain: glowbay-order-fulfillment
 * WC requires at least: 6.0
 * WC tested up to: 9.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('GB_Order_Fulfillment_Admin')) {
    require_once __DIR__ . '/class-gb-order-fulfillment-admin.php';
}
