<?php
/**
 * Plugin Name: GlowBay Mobile App API
 * Plugin URI: https://glowbaybd.com
 * Description: Dedicated, high-performance REST API gateway for GlowBayBD Flutter Mobile App & Dynamic Payment Methods synchronization.
 * Version: 1.2.0
 * Author: GlowBay Engineering
 * Text Domain: glowbay-app-api
 */

if (!defined('ABSPATH')) {
    exit;
}

class GlowBay_App_API {

    const REST_NAMESPACE = 'glowbay-app/v1';

    public function __construct() {
        $admin_fulfillment = dirname(__DIR__) . '/website-checkout-templates/class-gb-order-fulfillment-admin.php';
        if (file_exists($admin_fulfillment)) {
            require_once $admin_fulfillment;
        }

        add_action('rest_api_init', [$this, 'register_rest_routes']);
        add_action('wp_footer', [$this, 'sync_live_checkout_payment_numbers'], 9999);
    }

    public function register_rest_routes() {
        // 1. Home Feed
        register_rest_route(self::REST_NAMESPACE, '/home', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_home_feed'],
            'permission_callback' => '__return_true',
        ]);

        // 2. Flash Sale
        register_rest_route(self::REST_NAMESPACE, '/flash-sale', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_flash_sale'],
            'permission_callback' => '__return_true',
        ]);

        // 3. Categories List
        register_rest_route(self::REST_NAMESPACE, '/categories', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_categories'],
            'permission_callback' => '__return_true',
        ]);

        // 4. Brands List
        register_rest_route(self::REST_NAMESPACE, '/brands', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_brands'],
            'permission_callback' => '__return_true',
        ]);

        // 5. Products Catalog & Search/Filter
        register_rest_route(self::REST_NAMESPACE, '/products', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_products'],
            'permission_callback' => '__return_true',
        ]);

        // 5.1 Smart Barcode & Visual Query Product Lookup
        register_rest_route(self::REST_NAMESPACE, '/products/lookup-barcode', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'lookup_product_barcode'],
            'permission_callback' => '__return_true',
        ]);

        // 6. Single Product Details
        register_rest_route(self::REST_NAMESPACE, '/products/(?P<id>\d+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_product_details'],
            'permission_callback' => '__return_true',
        ]);

        // 7. Create Order (Checkout)
        register_rest_route(self::REST_NAMESPACE, '/orders/create', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'create_order'],
            'permission_callback' => '__return_true',
        ]);

        // 7.1 Cancel Order (Instant Cancellation & Stock Restoration)
        register_rest_route(self::REST_NAMESPACE, '/orders/(?P<id>\d+)/cancel', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'cancel_order'],
            'permission_callback' => '__return_true',
        ]);

        // 7.2 Resubmit Corrected Payment Details
        register_rest_route(self::REST_NAMESPACE, '/orders/(?P<id>\d+)/resubmit-payment', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'resubmit_payment'],
            'permission_callback' => '__return_true',
        ]);

        // 7.3 Request Return / Refund (7-Day Return Engine)
        register_rest_route(self::REST_NAMESPACE, '/orders/(?P<id>\d+)/request-return', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'request_return'],
            'permission_callback' => '__return_true',
        ]);

        // 8. Track Order (By ID or Tracking Number) - supports /orders/track/{id} and /track-order/{id}
        register_rest_route(self::REST_NAMESPACE, '/orders/track/(?P<id>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'track_order'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('glowbay/v1', '/track-order/(?P<id>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'track_order'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route(self::REST_NAMESPACE, '/track-order/(?P<id>[a-zA-Z0-9_-]+)', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'track_order'],
            'permission_callback' => '__return_true',
        ]);

        // 8.1 Staff Camera Barcode Scanner Module (KL & Dhaka Hubs)
        register_rest_route('glowbay/v1', '/scan-barcode', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'staff_scan_barcode'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route(self::REST_NAMESPACE, '/scan-barcode', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'staff_scan_barcode'],
            'permission_callback' => '__return_true',
        ]);

        // 9. Auth: Login
        register_rest_route(self::REST_NAMESPACE, '/auth/login', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'auth_login'],
            'permission_callback' => '__return_true',
        ]);

        // 10. Auth: Register
        register_rest_route(self::REST_NAMESPACE, '/auth/register', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'auth_register'],
            'permission_callback' => '__return_true',
        ]);

        // 11. Auth: Social Login
        register_rest_route(self::REST_NAMESPACE, '/auth/social-login', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'auth_social_login'],
            'permission_callback' => '__return_true',
        ]);

        // 11.1 Auth: Forgot Password
        register_rest_route(self::REST_NAMESPACE, '/auth/forgot-password', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'auth_forgot_password'],
            'permission_callback' => '__return_true',
        ]);

        // 12. User Dashboard
        register_rest_route(self::REST_NAMESPACE, '/user/dashboard', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_user_dashboard'],
            'permission_callback' => [$this, 'require_auth_permission'],
        ]);

        // 13. User Orders
        register_rest_route(self::REST_NAMESPACE, '/user/orders', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_user_orders'],
            'permission_callback' => [$this, 'require_auth_permission'],
        ]);

        // 14. User Addresses
        register_rest_route(self::REST_NAMESPACE, '/user/addresses', [
            'methods'             => [WP_REST_Server::READABLE, WP_REST_Server::CREATABLE],
            'callback'            => [$this, 'handle_user_addresses'],
            'permission_callback' => [$this, 'require_auth_permission'],
        ]);

        // 15. Vouchers / Coupons
        register_rest_route(self::REST_NAMESPACE, '/vouchers', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_vouchers'],
            'permission_callback' => '__return_true',
        ]);

        // 16. Sourcing / Product Request
        register_rest_route(self::REST_NAMESPACE, '/request-product', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'submit_product_request'],
            'permission_callback' => '__return_true',
        ]);

        // 17. Affiliate Stats
        register_rest_route(self::REST_NAMESPACE, '/affiliate/stats', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_affiliate_stats'],
            'permission_callback' => '__return_true',
        ]);

        // 18. Payment Methods & Account Settings
        register_rest_route(self::REST_NAMESPACE, '/payment-methods', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_payment_methods'],
            'permission_callback' => '__return_true',
        ]);

        // 19. Coupon Validation
        register_rest_route(self::REST_NAMESPACE, '/coupons/validate', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'validate_coupon'],
            'permission_callback' => '__return_true',
        ]);

        // 20. Verified Customer Reviews
        register_rest_route(self::REST_NAMESPACE, '/reviews', [
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => [$this, 'get_verified_reviews'],
            'permission_callback' => '__return_true',
        ]);

        // 21. FCM Device Token Registration
        register_rest_route(self::REST_NAMESPACE, '/notifications/register-token', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'register_device_token'],
            'permission_callback' => '__return_true',
        ]);

        // 22. Send / Broadcast Notification
        register_rest_route(self::REST_NAMESPACE, '/notifications/broadcast', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'broadcast_push_notification'],
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Standard unified JSON response helper
     */
    private function json_success($data = [], $message = 'Success') {
        return rest_ensure_response([
            'success' => true,
            'status'  => 'success',
            'message' => $message,
            'data'    => $data,
        ]);
    }

    private function json_error($message = 'Something went wrong', $code = 'error', $status_code = 400) {
        return new WP_Error($code, $message, [
            'status'  => $status_code,
            'success' => false,
        ]);
    }

    /**
     * Format a WooCommerce product object into a clean mobile app payload
     */
    private function format_product($product) {
        if (!is_a($product, 'WC_Product')) {
            $product = wc_get_product($product);
        }
        if (!$product) {
            return null;
        }

        $id = $product->get_id();
        $image_id = $product->get_image_id();
        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail') : '';
        if (!$image_url && $image_id) {
            $image_url = wp_get_attachment_url($image_id);
        }
        if (!$image_url) {
            $image_url = function_exists('wc_placeholder_img_src') ? wc_placeholder_img_src('woocommerce_thumbnail') : '';
        }

        // Gallery
        $gallery_ids = $product->get_gallery_image_ids();
        $gallery_urls = [];
        if ($image_url) {
            $gallery_urls[] = $image_url;
        }
        foreach ($gallery_ids as $gid) {
            $g_url = wp_get_attachment_image_url($gid, 'large');
            if ($g_url && !in_array($g_url, $gallery_urls)) {
                $gallery_urls[] = $g_url;
            }
        }

        // Pricing
        $reg_price = (float) $product->get_regular_price();
        $sale_price = (float) $product->get_sale_price();
        $price = (float) $product->get_price();
        $on_sale = $product->is_on_sale();

        $discount_pct = 0;
        if ($reg_price > 0 && $sale_price > 0 && $reg_price > $sale_price) {
            $discount_pct = round((($reg_price - $sale_price) / $reg_price) * 100);
        }

        // Brands
        $brands = [];
        $brand_terms = wp_get_post_terms($id, 'product_brand');
        if (empty($brand_terms) || is_wp_error($brand_terms)) {
            $brand_terms = wp_get_post_terms($id, 'brand');
        }
        if (!empty($brand_terms) && !is_wp_error($brand_terms)) {
            foreach ($brand_terms as $bt) {
                $brands[] = [
                    'id'   => $bt->term_id,
                    'name' => $bt->name,
                    'slug' => $bt->slug,
                ];
            }
        }

        // Categories
        $categories = [];
        $cat_ids = $product->get_category_ids();
        foreach ($cat_ids as $cid) {
            $term = get_term($cid, 'product_cat');
            if ($term && !is_wp_error($term)) {
                $categories[] = [
                    'id'   => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                ];
            }
        }

        $total_sales = (int) $product->get_total_sales();
        $rating_count = (int) $product->get_rating_count();
        $average_rating = (float) $product->get_average_rating();

        return [
            'id'                  => $id,
            'name'                => $product->get_name(),
            'slug'                => $product->get_slug(),
            'permalink'           => $product->get_permalink(),
            'price'               => $price > 0 ? $price : $reg_price,
            'regular_price'       => $reg_price > 0 ? $reg_price : $price,
            'sale_price'          => $sale_price > 0 ? $sale_price : null,
            'on_sale'             => $on_sale,
            'discount_percentage' => $discount_pct,
            'currency'            => '৳',
            'image'               => $image_url,
            'gallery'             => $gallery_urls,
            'in_stock'            => $product->is_in_stock(),
            'stock_status'        => $product->get_stock_status(),
            'stock_quantity'      => $product->get_stock_quantity(),
            'weight_g'            => (float) $product->get_weight(),
            'sku'                 => $product->get_sku(),
            'brands'              => $brands,
            'categories'          => $categories,
            'total_sales'         => $total_sales,
            'rating_count'        => $rating_count,
            'average_rating'      => $average_rating > 0 ? $average_rating : 5.0,
            'is_authentic'        => true,
            'origin'              => 'Malaysia',
            'short_description'   => wp_strip_all_tags($product->get_short_description()),
        ];
    }

    /**
     * 1. Home Feed
     */
    public function get_home_feed(WP_REST_Request $request) {
        $saved_banners = get_option('_glowbay_app_banners');
        $banners = [];
        if (!empty($saved_banners) && is_array($saved_banners)) {
            $banners = $saved_banners;
        } else {
            // Build dynamic banners from real store assets
            $banners = [
                [
                    'id'          => 1,
                    'title'       => '100% Authentic Malaysian Skincare',
                    'subtitle'    => 'Direct Air Cargo from Kuala Lumpur to Dhaka',
                    'image'       => home_url('/wp-content/themes/glowbayhp/assets/brands/cerave.png'),
                    'bg_gradient' => ['#0F172A', '#1E293B'],
                    'target_type' => 'category',
                    'target_id'   => 'facial-cleanser',
                ],
                [
                    'id'          => 2,
                    'title'       => 'Authentic Australian & Asian Vitamins',
                    'subtitle'    => 'Blackmores, Swisse & Wellness Essentials',
                    'image'       => home_url('/wp-content/themes/glowbayhp/assets/brands/blackmores.png'),
                    'bg_gradient' => ['#064E3B', '#047857'],
                    'target_type' => 'brand',
                    'target_id'   => 'blackmores',
                ],
                [
                    'id'          => 3,
                    'title'       => 'Daily UV Defense & Brightening',
                    'subtitle'    => 'Top Japanese & Korean Sunscreens',
                    'image'       => home_url('/wp-content/themes/glowbayhp/assets/brands/biore.png'),
                    'bg_gradient' => ['#831843', '#BE185D'],
                    'target_type' => 'category',
                    'target_id'   => 'sunscreen',
                ],
            ];
        }

        $channels = [
            ['id' => 'cleansers', 'name' => 'Cleansers', 'icon' => 'sparkles', 'slug' => 'facial-cleanser'],
            ['id' => 'moisturizers', 'name' => 'Moisturizers', 'icon' => 'droplet', 'slug' => 'skincare-moisturizer'],
            ['id' => 'serum', 'name' => 'Serums', 'icon' => 'flask', 'slug' => 'serum'],
            ['id' => 'sunscreen', 'name' => 'Sunscreen', 'icon' => 'sun', 'slug' => 'sunscreen'],
            ['id' => 'haircare', 'name' => 'Hair Care', 'icon' => 'scissors', 'slug' => 'haircare'],
            ['id' => 'supplements', 'name' => 'Vitamins', 'icon' => 'shield-halved', 'slug' => 'health-supplements'],
        ];

        // Flash Sale - Connected directly to GlowBay Flashsale Plugin Database
        global $wpdb;
        $tp = $wpdb->prefix . 'glowbay_flash_';
        $now_utc = gmdate('Y-m-d H:i:s');

        $active_camp = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tp}campaigns 
             WHERE status = 'active' 
               AND (start_utc IS NULL OR start_utc <= %s) 
               AND (end_utc IS NULL OR end_utc >= %s)
             ORDER BY priority DESC, id DESC LIMIT 1",
            $now_utc, $now_utc
        ));

        $is_flash_active = ($active_camp && !empty($active_camp->id) && !empty($active_camp->end_utc) && strtotime($active_camp->end_utc . ' UTC') > time());
        $flash_title = $is_flash_active ? $active_camp->name : '';
        $flash_subtitle = $is_flash_active ? ($active_camp->description ?: 'Limited Time Authentic Offers') : '';
        $flash_end_ts = $is_flash_active ? strtotime($active_camp->end_utc . ' UTC') : 0;

        $flash_products = [];
        if ($is_flash_active) {
            $c_prods = $wpdb->get_results($wpdb->prepare(
                "SELECT cp.product_id, cp.discount_value, cp.flash_price 
                 FROM {$tp}campaign_products cp 
                 WHERE cp.campaign_id = %d 
                 ORDER BY cp.id ASC LIMIT 10",
                (int)$active_camp->id
            ));
            foreach ($c_prods as $cp) {
                $p = wc_get_product((int)$cp->product_id);
                if ($p && $p->is_visible()) {
                    $formatted = $this->format_product($p);
                    if ($formatted) {
                        if (!empty($cp->flash_price) && (float)$cp->flash_price > 0) {
                            $formatted['sale_price'] = (float)$cp->flash_price;
                            $formatted['price'] = (float)$cp->flash_price;
                            $formatted['on_sale'] = true;
                            if ($formatted['regular_price'] > 0) {
                                $formatted['discount_percentage'] = round((($formatted['regular_price'] - $formatted['price']) / $formatted['regular_price']) * 100);
                            }
                        }
                        $formatted['sold_percentage'] = min(95, max(30, ($formatted['total_sales'] * 7 + 35) % 100));
                        $flash_products[] = $formatted;
                    }
                }
            }
        }

        // Query real WooCommerce product_brand taxonomy terms
        $top_brands = [];
        $brand_taxonomies = ['product_brand', 'brand'];
        foreach ($brand_taxonomies as $btax) {
            if (taxonomy_exists($btax)) {
                $terms = get_terms([
                    'taxonomy'   => $btax,
                    'hide_empty' => false,
                    'number'     => 12,
                    'orderby'    => 'count',
                    'order'      => 'DESC',
                ]);
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $t) {
                        $meta_logo = get_term_meta($t->term_id, 'thumbnail_id', true);
                        $logo_url = $meta_logo ? wp_get_attachment_image_url($meta_logo, 'medium') : home_url("/wp-content/themes/glowbayhp/assets/brands/{$t->slug}.png");
                        $top_brands[] = [
                            'id'       => $t->term_id,
                            'name'     => $t->name,
                            'slug'     => $t->slug,
                            'count'    => (int)$t->count,
                            'tagline'  => '100% Authentic Guaranteed',
                            'badge'    => 'Verified Official',
                            'logo'     => $logo_url,
                        ];
                    }
                    break;
                }
            }
        }
        if (empty($top_brands)) {
            $default_brand_names = ['Nivea', 'Vaseline', 'La Roche-Posay', 'Dove', 'Watsons', 'Eucerin', 'Biore', 'Blackmores', 'Cetaphil', 'CeraVe', 'Cosrx', 'Fino'];
            foreach ($default_brand_names as $bname) {
                $bslug = sanitize_title($bname);
                $top_brands[] = [
                    'name'    => $bname,
                    'slug'    => $bslug,
                    'tagline' => '100% Authentic Guaranteed',
                    'badge'   => 'Verified Official',
                    'logo'    => home_url("/wp-content/themes/glowbayhp/assets/brands/{$bslug}.png"),
                ];
            }
        }

        $for_you_products = [];
        if (class_exists('WC_Product_Query')) {
            $for_you_query = new WC_Product_Query([
                'limit'   => 12,
                'page'    => 1,
                'status'  => 'publish',
                'orderby' => 'date',
                'order'   => 'DESC',
            ]);
            foreach ($for_you_query->get_products() as $p) {
                $formatted = $this->format_product($p);
                if ($formatted) {
                    $for_you_products[] = $formatted;
                }
            }
        }

        return $this->json_success([
            'banners'          => $banners,
            'channels'         => $channels,
            'quick_categories' => $channels,
            'flash_sale'       => [
                'is_active'      => $is_flash_active && !empty($flash_products),
                'title'          => $flash_title,
                'subtitle'       => $flash_subtitle,
                'end_timestamp'  => $flash_end_ts,
                'products'       => $flash_products,
            ],
            'top_brands'       => $top_brands,
            'authentic_brands' => $top_brands,
            'for_you'          => $for_you_products,
            'just_for_you'     => [
                'page'     => 1,
                'has_more' => count($for_you_products) >= 12,
                'products' => $for_you_products,
            ],
        ]);
    }

    /**
     * 2. Flash Sale (Full Dedicated Landing Feed)
     */
    public function get_flash_sale(WP_REST_Request $request) {
        $per_page = (int) $request->get_param('per_page') ?: 30;
        $page = (int) $request->get_param('page') ?: 1;

        global $wpdb;
        $tp = $wpdb->prefix . 'glowbay_flash_';
        $now_utc = gmdate('Y-m-d H:i:s');

        $active_camp = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$tp}campaigns 
             WHERE status = 'active' 
               AND (start_utc IS NULL OR start_utc <= %s) 
               AND (end_utc IS NULL OR end_utc >= %s)
             ORDER BY priority DESC, id DESC LIMIT 1",
            $now_utc, $now_utc
        ));

        $is_flash_active = ($active_camp && !empty($active_camp->id) && !empty($active_camp->end_utc) && strtotime($active_camp->end_utc . ' UTC') > time());
        $camp_name = $is_flash_active ? $active_camp->name : '';
        $end_ts = $is_flash_active ? strtotime($active_camp->end_utc . ' UTC') : 0;

        $products = [];
        if ($is_flash_active) {
            $c_prods = $wpdb->get_results($wpdb->prepare(
                "SELECT cp.product_id, cp.discount_value, cp.flash_price 
                 FROM {$tp}campaign_products cp 
                 WHERE cp.campaign_id = %d 
                 ORDER BY cp.id ASC LIMIT %d",
                (int)$active_camp->id, $per_page
            ));
            foreach ($c_prods as $cp) {
                $p = wc_get_product((int)$cp->product_id);
                if ($p && $p->is_visible()) {
                    $formatted = $this->format_product($p);
                    if ($formatted) {
                        if (!empty($cp->flash_price) && (float)$cp->flash_price > 0) {
                            $formatted['sale_price'] = (float)$cp->flash_price;
                            $formatted['price'] = (float)$cp->flash_price;
                            $formatted['on_sale'] = true;
                            if ($formatted['regular_price'] > 0) {
                                $formatted['discount_percentage'] = round((($formatted['regular_price'] - $formatted['price']) / $formatted['regular_price']) * 100);
                            }
                        }
                        $formatted['sold_percentage'] = min(95, max(35, ($formatted['total_sales'] * 8 + 40) % 100));
                        $products[] = $formatted;
                    }
                }
            }
        }

        return $this->json_success([
            'is_active'     => $is_flash_active && !empty($products),
            'campaign_name' => $camp_name,
            'end_timestamp' => $end_ts,
            'products'      => $products,
        ]);
    }

    /**
     * 3. Categories List
     */
    public function get_categories(WP_REST_Request $request) {
        $terms = get_terms([
            'taxonomy'   => 'product_cat',
            'hide_empty' => false,
            'parent'     => 0,
        ]);

        $categories = [];
        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $t) {
                if ($t->slug === 'uncategorized') continue;
                $thumb_id = get_term_meta($t->term_id, 'thumbnail_id', true);
                $img_url = $thumb_id ? wp_get_attachment_url($thumb_id) : '';

                $children = get_terms([
                    'taxonomy'   => 'product_cat',
                    'hide_empty' => false,
                    'parent'     => $t->term_id,
                ]);
                $subcats = [];
                if (!empty($children) && !is_wp_error($children)) {
                    foreach ($children as $c) {
                        $subcats[] = [
                            'id'    => $c->term_id,
                            'name'  => $c->name,
                            'slug'  => $c->slug,
                            'count' => $c->count,
                        ];
                    }
                }

                $categories[] = [
                    'id'            => $t->term_id,
                    'name'          => $t->name,
                    'slug'          => $t->slug,
                    'count'         => $t->count,
                    'image'         => $img_url,
                    'subcategories' => $subcats,
                ];
            }
        }

        return $this->json_success($categories);
    }

    /**
     * 4. Brands List
     */
    public function get_brands(WP_REST_Request $request) {
        $brand_tax = taxonomy_exists('product_brand') ? 'product_brand' : 'brand';
        $terms = get_terms([
            'taxonomy'   => $brand_tax,
            'hide_empty' => false,
        ]);

        $brands = [];
        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $t) {
                $brands[] = [
                    'id'    => $t->term_id,
                    'name'  => $t->name,
                    'slug'  => $t->slug,
                    'count' => $t->count,
                ];
            }
        }

        return $this->json_success($brands);
    }

    /**
     * 5. Products Catalog & Filter
     */
    public function get_products(WP_REST_Request $request) {
        $per_page = (int) $request->get_param('per_page') ?: 12;
        $page = (int) $request->get_param('page') ?: 1;
        $search = sanitize_text_field($request->get_param('search'));
        $category = sanitize_text_field($request->get_param('category'));
        $brand = sanitize_text_field($request->get_param('brand'));
        $min_price = $request->get_param('min_price');
        $max_price = $request->get_param('max_price');
        $orderby = sanitize_text_field($request->get_param('orderby')) ?: 'date';
        $order = sanitize_text_field($request->get_param('order')) ?: 'DESC';

        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'order'          => strtoupper($order),
        ];

        if (!empty($search)) {
            // Check if search matches SKU directly
            $sku_id = function_exists('wc_get_product_id_by_sku') ? wc_get_product_id_by_sku($search) : 0;
            if ($sku_id > 0) {
                $args['post__in'] = [$sku_id];
            } else {
                $args['s'] = $search;
            }
        }

        switch ($orderby) {
            case 'price':
                $args['meta_key'] = '_price';
                $args['orderby'] = 'meta_value_num';
                break;
            case 'popularity':
                $args['meta_key'] = 'total_sales';
                $args['orderby'] = 'meta_value_num';
                break;
            case 'rating':
                $args['meta_key'] = '_wc_average_rating';
                $args['orderby'] = 'meta_value_num';
                break;
            case 'title':
                $args['orderby'] = 'title';
                break;
            default:
                $args['orderby'] = 'date';
                break;
        }

        $tax_query = [];
        if (!empty($category)) {
            $field = is_numeric($category) ? 'term_id' : 'slug';
            $tax_query[] = [
                'taxonomy' => 'product_cat',
                'field'    => $field,
                'terms'    => $category,
            ];
        }
        if (!empty($brand)) {
            $brand_tax = taxonomy_exists('product_brand') ? 'product_brand' : 'brand';
            $field = is_numeric($brand) ? 'term_id' : 'slug';
            $tax_query[] = [
                'taxonomy' => $brand_tax,
                'field'    => $field,
                'terms'    => $brand,
            ];
        }
        if (!empty($tax_query)) {
            $args['tax_query'] = $tax_query;
        }

        if ($min_price !== null || $max_price !== null) {
            $meta_query = [];
            if ($min_price !== null && $max_price !== null) {
                $meta_query[] = [
                    'key'     => '_price',
                    'value'   => [(float) $min_price, (float) $max_price],
                    'type'    => 'NUMERIC',
                    'compare' => 'BETWEEN',
                ];
            } elseif ($min_price !== null) {
                $meta_query[] = [
                    'key'     => '_price',
                    'value'   => (float) $min_price,
                    'type'    => 'NUMERIC',
                    'compare' => '>=',
                ];
            } elseif ($max_price !== null) {
                $meta_query[] = [
                    'key'     => '_price',
                    'value'   => (float) $max_price,
                    'type'    => 'NUMERIC',
                    'compare' => '<=',
                ];
            }
            $args['meta_query'] = $meta_query;
        }

        $query = new WP_Query($args);
        $products = [];
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $formatted = $this->format_product(get_the_ID());
                if ($formatted) {
                    $products[] = $formatted;
                }
            }
            wp_reset_postdata();
        }

        return $this->json_success([
            'total'        => (int) $query->found_posts,
            'total_pages'  => (int) $query->max_num_pages,
            'current_page' => $page,
            'per_page'     => $per_page,
            'products'     => $products,
        ]);
    }

    /**
     * 5.1 Smart Multi-Stage Barcode & Visual Query Lookup
     */
    public function lookup_product_barcode(WP_REST_Request $request) {
        $code = sanitize_text_field($request->get_param('code') ?: $request->get_param('barcode') ?: $request->get_param('q'));
        if (empty($code)) {
            return $this->json_error('Barcode or query required', 'missing_param', 400);
        }

        global $wpdb;
        $found_product = null;

        // Stage 1: Match by WooCommerce SKU (exact or prefix)
        $product_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND (meta_value = %s OR meta_value LIKE %s) LIMIT 1",
            $code, '%' . $wpdb->esc_like($code) . '%'
        ));

        // Stage 2: Match by any barcode / EAN / UPC meta fields
        if (!$product_id) {
            $product_id = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('barcode', '_barcode', 'ean', '_ean', 'upc', '_upc', 'gtin') AND meta_value = %s LIMIT 1",
                $code
            ));
        }

        // Stage 3: Direct Product ID match if numeric
        if (!$product_id && is_numeric($code) && (int)$code > 0) {
            $p_check = wc_get_product((int)$code);
            if ($p_check && $p_check->is_visible()) {
                $product_id = (int)$code;
            }
        }

        // Stage 4: Smart Visual Keyword Search (if code contains brand/words e.g. from camera OCR/visual label)
        if (!$product_id) {
            $clean_terms = preg_split('/[\s\-_,]+/', strtolower($code));
            $clean_terms = array_filter($clean_terms, function($t) { return strlen($t) >= 3; });
            
            if (!empty($clean_terms)) {
                $first_term = reset($clean_terms);
                $product_id = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish' AND post_title LIKE %s ORDER BY ID DESC LIMIT 1",
                    '%' . $wpdb->esc_like($first_term) . '%'
                ));
            }
        }

        if ($product_id) {
            $product = wc_get_product($product_id);
            if ($product && $product->is_visible()) {
                return $this->json_success([
                    'matched' => true,
                    'method'  => 'verified_lookup',
                    'product' => $this->format_product($product),
                ]);
            }
        }

        return $this->json_error('No authentic product found matching barcode', 'not_found', 404);
    }

    /**
     * 6. Product Details (PDP)
     */
    public function get_product_details(WP_REST_Request $request) {
        $id = (int) $request->get_param('id');
        $product = function_exists('wc_get_product') ? wc_get_product($id) : null;

        if (!$product) {
            return $this->json_error('Product not found', 'not_found', 404);
        }

        $formatted = $this->format_product($product);
        $formatted['description_html'] = $product->get_description();
        $formatted['authenticity_guarantee'] = [
            'title'      => '100% Genuine Guaranteed',
            'origin'     => 'Sourced directly from official Malaysian authorized counters',
            'money_back' => '3x Money-Back Guarantee if proven fake',
            'seal_badge' => 'Authentic Batch Verified',
        ];

        $formatted['shipping_info'] = [
            'inside_dhaka_fee'  => 70,
            'outside_dhaka_fee' => 130,
            'estimated_days'    => '2 - 3 Days (Ready Stock)',
            'cod_available'     => true,
        ];

        $related_products = [];
        if (function_exists('wc_get_related_products')) {
            $related_ids = wc_get_related_products($id, 4);
            foreach ($related_ids as $rid) {
                $rp = $this->format_product($rid);
                if ($rp) {
                    $related_products[] = $rp;
                }
            }
        }
        $formatted['related_products'] = $related_products;

        return $this->json_success($formatted);
    }

    /**
     * 7. Create Order (Checkout)
     */
    public function create_order(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];

        // Support both flat and nested address formats
        $addr = isset($params['address']) && is_array($params['address']) ? $params['address'] : [];
        $customer_name   = sanitize_text_field($params['name'] ?? ($addr['name'] ?? ''));
        $customer_phone  = sanitize_text_field($params['phone'] ?? ($addr['phone'] ?? ''));
        $customer_email  = sanitize_email($params['email'] ?? ($addr['email'] ?? ''));
        $division        = sanitize_text_field($params['division'] ?? ($addr['division'] ?? ''));
        $district        = sanitize_text_field($params['district'] ?? ($addr['district'] ?? ''));
        $upazila         = sanitize_text_field($params['upazila'] ?? ($addr['upazila'] ?? ''));
        $street_address  = sanitize_text_field($params['address'] && is_string($params['address']) ? $params['address'] : ($addr['street'] ?? ($addr['address'] ?? '')));
        $payment_method  = sanitize_text_field($params['payment_method'] ?? 'cod');
        $customer_note   = sanitize_textarea_field($params['note'] ?? '');
        $items           = $params['items'] ?? [];

        // Payment & Advance Meta Fields
        $preorder_payment_mode = sanitize_text_field($params['preorder_payment_mode'] ?? ($params['payment_plan'] ?? 'advance_50'));
        $sender_number = sanitize_text_field($params['sender_number'] ?? ($params['gb_sender'] ?? ''));
        $trx_id = sanitize_text_field($params['trx_id'] ?? ($params['gb_trxid'] ?? ''));
        $bank_ref = sanitize_text_field($params['bank_ref'] ?? ($params['gb_bank_ref'] ?? ''));
        $receipt_base64 = $params['receipt_base64'] ?? '';
        $receipt_filename = sanitize_file_name($params['receipt_filename'] ?? ('receipt_' . time() . '.jpg'));

        if (empty($customer_name) || empty($customer_phone) || empty($street_address) || empty($items)) {
            return $this->json_error('Name, phone number, delivery address, and cart items are required.', 'invalid_data', 400);
        }

        if (empty($customer_email)) {
            $cleaned_phone = preg_replace('/[^0-9]/', '', $customer_phone);
            $customer_email = $cleaned_phone . '@glowbaybd.com';
        }

        try {
            if (!function_exists('wc_create_order')) {
                return $this->json_error('WooCommerce is not active.', 'wc_missing', 500);
            }

            $order = wc_create_order();

            foreach ($items as $item) {
                $pid = (int) ($item['product_id'] ?? 0);
                $qty = max(1, (int) ($item['quantity'] ?? 1));
                $product = wc_get_product($pid);
                if ($product) {
                    $order->add_product($product, $qty);
                }
            }

            $full_address = trim("$street_address, $upazila, $district, $division");
            $address_data = [
                'first_name' => $customer_name,
                'email'      => $customer_email,
                'phone'      => $customer_phone,
                'address_1'  => $full_address,
                'city'       => $district ?: 'Dhaka',
                'state'      => $division ?: 'Dhaka',
                'country'    => 'BD',
            ];
            $order->set_address($address_data, 'billing');
            $order->set_address($address_data, 'shipping');

            // Shipping Calculation (80 for Dhaka, 130 for Outside Dhaka matching web)
            $shipping_cost = (strtolower($district) === 'dhaka') ? 80 : 130;
            $shipping_item = new WC_Order_Item_Shipping();
            $shipping_item->set_method_title('Standard Express Delivery');
            $shipping_item->set_method_id('flat_rate');
            $shipping_item->set_total($shipping_cost);
            $order->add_item($shipping_item);

            // Payment Title
            $payment_title = match ($payment_method) {
                'glowbay_bkash', 'bkash' => 'bKash Online / Manual',
                'glowbay_nagad', 'nagad' => 'Nagad Online / Manual',
                'glowbay_bank', 'bank'   => 'Direct Bank Transfer',
                default                  => 'Cash on Delivery (COD)',
            };
            $order->set_payment_method($payment_method);
            $order->set_payment_method_title($payment_title);

            if (!empty($customer_note)) {
                $order->set_customer_note($customer_note);
            }

            // Calculate Totals first
            $order->calculate_totals();
            $total = (float) $order->get_total();
            $advance_amount = ($preorder_payment_mode === 'advance_50') ? round($total * 0.5) : $total;
            $due_amount = max(0, $total - $advance_amount);

            // Process receipt screenshot upload if provided with strict MIME type validation
            $receipt_url = '';
            if (!empty($receipt_base64)) {
                $raw_data = preg_replace('#^data:image/\w+;base64,#i', '', $receipt_base64);
                $image_data = base64_decode($raw_data);
                if ($image_data !== false && strlen($image_data) > 64) {
                    $img_info = @getimagesizefromstring($image_data);
                    if ($img_info !== false && !empty($img_info['mime'])) {
                        $mime = strtolower($img_info['mime']);
                        $ext_map = [
                            'image/jpeg' => 'jpg',
                            'image/jpg'  => 'jpg',
                            'image/png'  => 'png',
                            'image/webp' => 'webp',
                        ];
                        if (isset($ext_map[$mime])) {
                            $safe_filename = 'receipt_' . $order->get_id() . '_' . bin2hex(random_bytes(6)) . '.' . $ext_map[$mime];
                            $upload = wp_upload_bits($safe_filename, null, $image_data);
                            if (empty($upload['error']) && !empty($upload['url'])) {
                                $receipt_url = $upload['url'];
                            }
                        }
                    }
                }
            }

            // Save standard & plugin metadata
            $order->update_meta_data('_created_via', 'glowbay_flutter_app');
            $order->update_meta_data('_app_version', '1.2.0');
            $order->update_meta_data('_preorder_payment_mode', $preorder_payment_mode);
            $order->update_meta_data('preorder_payment_mode', $preorder_payment_mode);
            $order->update_meta_data('_gb_payment_method', $payment_method);
            $order->update_meta_data('_gb_advance_paid', $advance_amount);
            $order->update_meta_data('_gb_due_amount', $due_amount);

            if ($payment_method === 'glowbay_bkash' || strpos($payment_method, 'bkash') !== false) {
                if ($sender_number) {
                    $order->update_meta_data('_gb_bkash_sender', $sender_number);
                    $order->update_meta_data('gb_bkash_sender', $sender_number);
                }
                if ($trx_id) {
                    $order->update_meta_data('_gb_bkash_trxid', $trx_id);
                    $order->update_meta_data('gb_bkash_trxid', $trx_id);
                }
            } else if ($payment_method === 'glowbay_nagad' || strpos($payment_method, 'nagad') !== false) {
                if ($sender_number) {
                    $order->update_meta_data('_gb_nagad_sender', $sender_number);
                    $order->update_meta_data('gb_nagad_sender', $sender_number);
                }
                if ($trx_id) {
                    $order->update_meta_data('_gb_nagad_trxid', $trx_id);
                    $order->update_meta_data('gb_nagad_trxid', $trx_id);
                }
            } else if ($payment_method === 'glowbay_bangla_qr' || strpos($payment_method, 'bangla') !== false || strpos($payment_method, 'qr') !== false) {
                $ref_val = $trx_id ?: $bank_ref ?: $sender_number;
                if ($ref_val) {
                    $order->update_meta_data('_gb_bangla_qr_ref', $ref_val);
                    $order->update_meta_data('gb_bangla_qr_ref', $ref_val);
                    $order->update_meta_data('_gb_bank_ref', $ref_val);
                }
            } else if ($payment_method === 'glowbay_bank' || strpos($payment_method, 'bank') !== false) {
                $ref_val = $bank_ref ?: $trx_id ?: $sender_number;
                if ($ref_val) {
                    $order->update_meta_data('_gb_bank_ref', $ref_val);
                    $order->update_meta_data('gb_bank_ref', $ref_val);
                }
            }

            if ($receipt_url) {
                $order->update_meta_data('_gb_payment_receipt_url', $receipt_url);
                $order->update_meta_data('gb_receipt_url', $receipt_url);
            }

            $has_payment_info = !empty($trx_id) || !empty($receipt_url);
            if ($has_payment_info) {
                $order->update_meta_data('_gb_payment_status', 'under_review');
                $order->update_status('wc-payment-review', 'Payment submitted by customer. Awaiting Admin verification.');
            } else {
                $order->update_meta_data('_gb_payment_status', 'pending');
                $order->update_status('wc-to-pay', 'Order created. Complete payment within 3 hours.');
            }

            return $this->json_success([
                'order_id'       => $order->get_id(),
                'total'          => $total,
                'advance_amount' => $advance_amount,
                'due_amount'     => $due_amount,
                'currency'       => '৳',
                'receipt_url'    => $receipt_url,
                'payment_status' => $has_payment_info ? 'under_review' : 'pending',
                'deadline_ts'    => time() + (3 * 3600),
            ], 'Order placed successfully.');

        } catch (Exception $e) {
            return $this->json_error($e->getMessage(), 'order_creation_failed', 500);
        }
    }

    /**
     * 7.1 Cancel Order (Instant Cancellation & Stock Restoration)
     */
    public function cancel_order(WP_REST_Request $request) {
        $order_id = (int) $request->get_param('id');
        $params   = $request->get_json_params() ?: $request->get_params();
        $reason   = sanitize_text_field($params['reason'] ?? 'Cancelled by customer');

        $order = wc_get_order($order_id);
        if (!$order) {
            return $this->json_error('অর্ডার পাওয়া যায়নি।', 'not_found', 404);
        }

        $tracking_stage = (int) get_post_meta($order_id, '_gb_tracking_stage', true);
        if ($tracking_stage >= 3 || in_array($order->get_status(), ['wc-in-transit', 'wc-arrived-dhaka', 'completed'])) {
            return $this->json_error('পণ্যটি ইতোমধ্যে আন্তর্জাতিক ট্রানজিটে রয়েছে। ক্যানসেল করতে কাস্টমার কেয়ারে যোগাযোগ করুন।', 'cannot_cancel', 400);
        }

        $order->update_meta_data('_gb_is_cancelled', true);
        $order->update_meta_data('_gb_cancellation_reason', $reason);
        $order->update_meta_data('_gb_cancelled_time', wp_date('d M Y, h:i A'));
        $order->update_status('cancelled', "Order cancelled by customer. Reason: $reason");

        // Restock inventory
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if ($product && $product->managing_stock()) {
                wc_update_product_stock($product, $item->get_quantity(), 'increase');
            }
        }
        $order->save();

        return $this->json_success([
            'order_id' => $order_id,
            'status'   => 'cancelled',
            'reason'   => $reason,
        ], 'অর্ডারটি সফলভাবে বাতিল করা হয়েছে এবং স্টক রিস্টোর করা হয়েছে।');
    }

    /**
     * 7.2 Resubmit Corrected Payment Details
     */
    public function resubmit_payment(WP_REST_Request $request) {
        $order_id = (int) $request->get_param('id');
        $params   = $request->get_json_params() ?: $request->get_params();
        $trx_id   = sanitize_text_field($params['trx_id'] ?? '');
        $sender   = sanitize_text_field($params['sender_number'] ?? '');
        $receipt  = sanitize_text_field($params['receipt_url'] ?? '');

        $order = wc_get_order($order_id);
        if (!$order) {
            return $this->json_error('অর্ডার পাওয়া যায়নি।', 'not_found', 404);
        }

        if (empty($trx_id) && empty($receipt)) {
            return $this->json_error('সঠিক TrxID বা রিসিট ছবি দিন।', 'missing_data', 400);
        }

        if ($trx_id) {
            $order->update_meta_data('_gb_trx_id', $trx_id);
            $order->set_transaction_id($trx_id);
        }
        if ($sender) {
            $order->update_meta_data('_gb_sender_number', $sender);
        }
        if ($receipt) {
            $order->update_meta_data('_gb_receipt_url', $receipt);
        }

        $order->update_meta_data('_gb_payment_status', 'under_review');
        $order->delete_meta_data('_gb_payment_rejection_reason');
        $order->update_status('wc-payment-review', "Customer resubmitted payment. TrxID: $trx_id, Sender: $sender. Awaiting admin review.");
        $order->save();

        return $this->json_success([
            'order_id'       => $order_id,
            'payment_status' => 'under_review',
        ], 'পেমেন্ট তথ্য সফলভাবে জমা দেওয়া হয়েছে। অ্যাডমিন যাচাই করছেন।');
    }

    /**
     * 7.3 Request Return / Refund (Within 7 Days of Delivery)
     */
    public function request_return(WP_REST_Request $request) {
        $order_id = (int) $request->get_param('id');
        $params   = $request->get_json_params() ?: $request->get_params();
        $reason   = sanitize_text_field($params['reason'] ?? 'Damaged / Incorrect Item');
        $notes    = sanitize_textarea_field($params['notes'] ?? '');

        $order = wc_get_order($order_id);
        if (!$order) {
            return $this->json_error('অর্ডার পাওয়া যায়নি।', 'not_found', 404);
        }

        $delivered_time = $order->get_date_completed() ? $order->get_date_completed()->getTimestamp() : 0;
        if ($delivered_time > 0 && (time() - $delivered_time) > (7 * DAY_IN_SECONDS)) {
            return $this->json_error('৭ দিনের রিটার্ন মেয়াদ শেষ হয়ে গেছে।', 'return_expired', 400);
        }

        $order->update_meta_data('_gb_return_reason', $reason);
        $order->update_meta_data('_gb_return_notes', $notes);
        $order->update_meta_data('_gb_return_status', 'under_review');
        $order->update_meta_data('_gb_return_requested_time', wp_date('d M Y, h:i A'));
        $order->update_status('wc-return-review', "Customer requested return within 7-day window. Reason: $reason. Notes: $notes");
        $order->save();

        return $this->json_success([
            'order_id'      => $order_id,
            'return_status' => 'under_review',
        ], 'রিটার্ন আবেদন সফলভাবে জমা হয়েছে। আমাদের সাপোর্ট টিম পর্যালোচনা করছে।');
    }

    /**
     * 8. Track Order
     */
    /**
     * 8. Track Order (5-Stage Cross-Border Malaysia to BD Lifecycle + Embedded Steadfast Courier Telemetry)
     */
    public function track_order(WP_REST_Request $request) {
        $identifier = sanitize_text_field($request->get_param('id'));
        $order = null;

        if (is_numeric($identifier)) {
            $order = wc_get_order((int) $identifier);
        } else {
            // Search by billing phone, order key, or consignment ID
            $orders = wc_get_orders([
                'billing_phone' => $identifier,
                'limit'         => 1,
                'orderby'       => 'date',
                'order'         => 'DESC',
            ]);
            if (!empty($orders)) {
                $order = $orders[0];
            } else {
                $meta_orders = wc_get_orders([
                    'meta_query' => [
                        'relation' => 'OR',
                        ['key' => '_steadfast_consignment_id', 'value' => $identifier, 'compare' => '='],
                        ['key' => '_courier_code', 'value' => $identifier, 'compare' => '='],
                    ],
                    'limit' => 1,
                ]);
                if (!empty($meta_orders)) {
                    $order = $meta_orders[0];
                }
            }
        }

        if (!$order) {
            return $this->json_error('Order not found matching identification.', 'not_found', 404);
        }

        $order_id = $order->get_id();
        $status = strtolower($order->get_status());
        $date_created = $order->get_date_created() ? $order->get_date_created()->date('d M Y, h:i A') : '';
        $date_created_ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time();

        // 1. Destination & City Analysis
        $city = strtolower($order->get_shipping_city() ?: $order->get_billing_city() ?: '');
        $address = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() . ', ' . $city);
        $full_addr_str = strtolower($order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ?: $address);
        $is_inside_dhaka = (strpos($full_addr_str, 'dhaka') !== false || strpos($city, 'dhaka') !== false);

        // 2. Financial calculation (50% booking vs remaining COD balance)
        $total = (float) $order->get_total();
        $advance_paid_meta = get_post_meta($order_id, '_advance_paid', true);
        $advance_paid = $advance_paid_meta !== '' ? (float) $advance_paid_meta : 0.0;
        if ($advance_paid <= 0 && ($status === 'processing' || $status === 'shipped' || $status === 'completed')) {
            // Default 50% booking policy
            $advance_paid = round($total * 0.5, 2);
        }
        $cod_balance = ($status === 'completed') ? 0.0 : max(0.0, round($total - $advance_paid, 2));

        // 3. Stage Determination (1 to 5, or 0 if Cancelled/Refunded/Failed)
        $meta_stage = (int) get_post_meta($order_id, '_gb_tracking_stage', true);
        $stage = 1;
        $is_cancelled = ($status === 'cancelled');
        $is_refunded = ($status === 'refunded');
        $is_failed = ($status === 'failed');

        $courier_code_check = get_post_meta($order_id, '_steadfast_consignment_id', true)
                           ?: get_post_meta($order_id, '_courier_code', true)
                           ?: get_post_meta($order_id, '_consignment_id', true);

        if ($is_cancelled || $is_refunded || $is_failed) {
            $stage = 0;
        } elseif (!empty($courier_code_check) || $status === 'completed' || $status === 'shipped') {
            // Steadfast consignment assigned and out for delivery => Stage 5 automatically
            $stage = 5;
        } elseif ($meta_stage >= 1 && $meta_stage <= 5) {
            $stage = $meta_stage;
        } else {
            if ($status === 'completed') {
                $stage = 5;
            } elseif (get_post_meta($order_id, '_gb_dhaka_arrive_time', true)) {
                $stage = 4;
            } elseif (get_post_meta($order_id, '_gb_kl_dispatch_time', true)) {
                $stage = 3;
            } elseif (get_post_meta($order_id, '_gb_packing_list_printed', true) || get_post_meta($order_id, '_gb_sourced', true)) {
                $stage = 2;
            } else {
                $stage = 1;
            }
        }

        // 4. Milestone Timestamps (Live DB timestamps or deterministic relative fallback)
        $time_stage1 = $date_created;
        $time_stage2 = get_post_meta($order_id, '_gb_sourced_time', true) ?: ($stage >= 2 ? wp_date('d M Y, h:i A', $date_created_ts + 86400) : '');
        $time_stage3 = get_post_meta($order_id, '_gb_kl_dispatch_time', true) ?: ($stage >= 3 ? wp_date('d M Y, h:i A', $date_created_ts + 172800) : '');
        $time_stage4 = get_post_meta($order_id, '_gb_dhaka_arrive_time', true) ?: ($stage >= 4 ? wp_date('d M Y, h:i A', $date_created_ts + 345600) : '');
        $time_stage5 = get_post_meta($order_id, '_gb_courier_dispatch_time', true) ?: ($stage >= 5 ? wp_date('d M Y, h:i A', $date_created_ts + 432000) : '');

        // 5. 5-Stage Cross-Border Customer Lifecycle
        $timeline = [
            [
                'stage'       => 1,
                'title'       => 'অর্ডার কনফার্মড — সোর্সিংয়ের অপেক্ষায়',
                'description' => 'অর্ডারটি ভেরিফাই করা হয়েছে, মালয়েশিয়া সেন্টারে সোর্সিং কিউতে রয়েছে।',
                'completed'   => ($stage >= 1),
                'active'      => ($stage === 1),
                'time'        => $time_stage1,
                'eta'         => '',
            ],
            [
                'stage'       => 2,
                'title'       => 'প্রোডাক্ট সোর্সিং সম্পন্ন হয়েছে',
                'description' => 'কুয়ালালামপুর সেন্ট্রাল থেকে আইটেম সংগ্রহ সম্পন্ন ও প্যাকিং স্লিপ প্রিন্ট হয়েছে।',
                'completed'   => ($stage >= 2),
                'active'      => ($stage === 2),
                'time'        => $time_stage2,
                'eta'         => '',
            ],
            [
                'stage'       => 3,
                'title'       => 'কুয়ালালামপুর থেকে ঢাকায় পাঠানো হচ্ছে (২–৪ দিনের মধ্যে ঢাকায় পৌঁছাবে)',
                'description' => 'এয়ার কার্গোর মাধ্যমে কুয়ালালামপুর থেকে ঢাকার উদ্দেশ্যে পাঠানো হয়েছে।',
                'completed'   => ($stage >= 3),
                'active'      => ($stage === 3),
                'time'        => $time_stage3,
                'eta'         => '২–৪ দিনের মধ্যে ঢাকায় পৌঁছাবে',
            ],
            [
                'stage'       => 4,
                'title'       => 'প্রোডাক্ট ঢাকা হাবে এসে পৌঁছেছে',
                'description' => 'পার্সেলটি ঢাকা সর্টিং হাবে রিসিভ ও কোয়ালিটি ইনস্পেকশন সম্পন্ন হয়েছে।',
                'completed'   => ($stage >= 4),
                'active'      => ($stage === 4),
                'time'        => $time_stage4,
                'eta'         => $is_inside_dhaka ? '১–২ দিনের মধ্যে ডেলিভারি' : '২–৩ দিনের মধ্যে ডেলিভারি',
            ],
            [
                'stage'       => 5,
                'title'       => 'ডেলিভারির জন্য পাঠানো হয়েছে',
                'description' => 'লোকাল কুরিয়ারে (Steadfast) হস্তান্তর করা হয়েছে এবং রাইডারের কাছে রয়েছে।',
                'completed'   => ($stage >= 5),
                'active'      => ($stage === 5),
                'time'        => $time_stage5,
                'eta'         => $is_inside_dhaka ? '১–২ দিনের মধ্যে ডেলিভারি' : '২–৩ দিনের মধ্যে ডেলিভারি',
            ],
        ];

        // 6. Steadfast Courier Telemetry
        $hub_loc = $is_inside_dhaka ? 'ঢাকা সেন্ট্রাল সর্টিং হাব, তেজগাঁও' : 'ঢাকা রিজিওনাল ডিসপ্যাচ হাব';
        $now_str = wp_date('d M Y, h:i A');

        if ($is_cancelled || $is_refunded || $is_failed) {
            $courier_code = '';
            $courier_telemetry = [
                'name'            => 'Steadfast Courier',
                'consignment_id'  => '',
                'tracking_code'   => '',
                'has_tracking'    => false,
                'status'          => $status,
                'status_bengali'  => $is_cancelled ? 'অর্ডারটি বাতিল করা হয়েছে (Cancelled)' : ($is_refunded ? 'অর্ডারের মূল্য রিফান্ড করা হয়েছে' : 'পেমেন্ট ব্যর্থ হয়েছে'),
                'hub_location'    => '',
                'last_updated'    => $now_str,
                'is_delivered'    => false,
                'cod_balance'     => 0.0,
                'cod_balance_formatted' => '৳0',
            ];
            $timeline = [
                [
                    'stage'       => 0,
                    'title'       => $is_cancelled ? 'Order Cancelled (অর্ডার বাতিল)' : ($is_refunded ? 'Order Refunded' : 'Order Failed'),
                    'description' => $is_cancelled ? 'This order has been cancelled and will not be processed.' : ($is_refunded ? 'The payment has been refunded.' : 'Order payment was not completed.'),
                    'completed'   => true,
                    'active'      => true,
                    'time'        => $date_created,
                    'eta'         => '',
                ]
            ];
        } else {
            $courier_code = get_post_meta($order_id, '_steadfast_consignment_id', true)
                         ?: get_post_meta($order_id, '_courier_code', true)
                         ?: get_post_meta($order_id, '_consignment_id', true)
                         ?: ($stage >= 5 ? 'ST-' . $order_id : '');

            $courier_status_bengali = 'পার্সেলটি ডেলিভারির জন্য রাইডারের কাছে আছে';
            if ($status === 'completed') {
                $courier_status_bengali = 'পার্সেলটি সফলভাবে কাস্টমারকে ডেলিভারি করা হয়েছে';
            } elseif ($stage === 4) {
                $courier_status_bengali = 'ঢাকা সর্টিং হাবে রয়েছে, কুরিয়ার পিকআপের প্রস্তুতি চলছে';
            } elseif ($stage === 3) {
                $courier_status_bengali = 'কুয়ালালামপুর থেকে এয়ার কার্গোতে ট্রানজিটে রয়েছে';
            } elseif ($stage <= 2) {
                $courier_status_bengali = 'কুয়ালালামপুর হাবে সোর্সিং ও প্যাকিং কিউতে রয়েছে';
            }

            $courier_telemetry = [
                'name'            => 'Steadfast Courier',
                'consignment_id'  => $courier_code,
                'tracking_code'   => $courier_code,
                'has_tracking'    => !empty($courier_code),
                'status'          => ($status === 'completed') ? 'delivered' : 'in_transit',
                'status_bengali'  => $courier_status_bengali,
                'hub_location'    => $hub_loc,
                'last_updated'    => $now_str,
                'is_delivered'    => ($status === 'completed'),
                'cod_balance'     => $cod_balance,
                'cod_balance_formatted' => '৳' . number_format($cod_balance, 0),
            ];
        }

        // Cache courier telemetry in order post meta
        update_post_meta($order_id, '_steadfast_cached_telemetry', $courier_telemetry);

        // 7. Order Items
        $items = [];
        foreach ($order->get_items() as $item) {
            $prod = $item->get_product();
            $img = '';
            if ($prod) {
                $img_id = $prod->get_image_id();
                if ($img_id) {
                    $img = wp_get_attachment_image_url($img_id, 'medium') ?: '';
                }
            }
            $items[] = [
                'name'            => $item->get_name(),
                'quantity'        => $item->get_quantity(),
                'total'           => (float) $item->get_total(),
                'formatted_total' => '৳' . number_format($item->get_total(), 0),
                'image'           => $img,
            ];
        }

        $payment_status           = $order->get_meta('_gb_payment_status') ?: 'pending';
        $payment_rejection_reason = $order->get_meta('_gb_payment_rejection_reason') ?: '';
        $cancellation_reason      = $order->get_meta('_gb_cancellation_reason') ?: '';
        $fulfillment_stage        = $order->get_meta('_gb_fulfillment_stage') ?: ($stage >= 3 ? 'in_transit' : ($stage == 2 ? 'packing' : 'sourcing'));
        $deadline_ts              = $date_created_ts + (3 * 3600);
        $remaining_seconds        = max(0, $deadline_ts - time());

        // 5-Funnel Classification
        $funnel_category = 'to_pay';
        if ($is_cancelled || $is_refunded || $order->get_meta('_gb_return_status')) {
            $funnel_category = 'returns';
        } elseif ($status === 'completed') {
            $funnel_category = 'delivered';
        } elseif ($stage >= 3 || in_array($status, ['wc-in-transit', 'wc-arrived-dhaka', 'shipped'])) {
            $funnel_category = 'in_transit';
        } elseif ($payment_status === 'approved' || in_array($status, ['processing', 'wc-to-ship'])) {
            $funnel_category = 'to_ship';
        } else {
            $funnel_category = 'to_pay';
        }

        $can_cancel   = ($stage < 3 && !$is_cancelled && !$is_refunded);
        $completed_ts = $order->get_date_completed() ? $order->get_date_completed()->getTimestamp() : 0;
        $can_return   = ($status === 'completed' && ($completed_ts > 0 ? (time() - $completed_ts <= 7 * DAY_IN_SECONDS) : true));
        $return_status= $order->get_meta('_gb_return_status') ?: '';

        return $this->json_success([
            'order_id'                 => $order_id,
            'current_stage'            => $stage,
            'status'                   => $status,
            'status_label'             => wc_get_order_status_name($status),
            'funnel_category'          => $funnel_category,
            'payment_status'           => $payment_status,
            'payment_rejection_reason' => $payment_rejection_reason,
            'payment_deadline_ts'      => $deadline_ts,
            'remaining_payment_seconds'=> $remaining_seconds,
            'fulfillment_stage'        => $fulfillment_stage,
            'can_cancel'               => $can_cancel,
            'can_return'               => $can_return,
            'return_status'            => $return_status,
            'cancellation_reason'      => $cancellation_reason,
            'is_cancelled'             => $is_cancelled,
            'is_refunded'              => $is_refunded,
            'is_inside_dhaka'          => $is_inside_dhaka,
            'eta_label'                => ($stage <= 3) ? '২–৪ দিনের মধ্যে ঢাকায় পৌঁছাবে' : ($is_inside_dhaka ? '১–২ দিনের মধ্যে ডেলিভারি' : '২–৩ দিনের মধ্যে ডেলিভারি'),
            'delivery_eta'             => $is_inside_dhaka ? '১–২ দিনের মধ্যে ডেলিভারি' : '২–৩ দিনের মধ্যে ডেলিভারি',
            'total'                    => $total,
            'formatted_total'          => '৳' . number_format($total, 0),
            'paid_amount'              => $advance_paid,
            'cod_balance'              => $cod_balance,
            'cod_balance_formatted'    => '৳' . number_format($cod_balance, 0),
            'billing_name'             => $order->get_formatted_billing_full_name() ?: 'GlowBay Customer',
            'billing_phone'            => $order->get_billing_phone() ?: '',
            'shipping_address'         => $address,
            'courier'                  => $courier_telemetry,
            'items'                    => $items,
            'timeline'                 => $timeline,
            'cached_at'                => $now_str,
        ]);
    }

    /**
     * 8.1 Staff Camera Barcode Scanner Module (KL & Dhaka Hubs)
     */
    public function staff_scan_barcode(WP_REST_Request $request) {
        $params  = $request->get_json_params() ?: $request->get_params();
        $barcode = sanitize_text_field($params['barcode'] ?? '');
        $action  = sanitize_text_field($params['action'] ?? '');
        $notes   = sanitize_text_field($params['staff_notes'] ?? '');

        if (empty($barcode)) {
            return $this->json_error('বারকোড বা পার্সেল নম্বর দিন।', 'missing_barcode', 400);
        }

        // Clean identifier (e.g. #12345 or ST-12345)
        $clean_id = preg_replace('/[^0-9]/', '', $barcode);
        $order = null;
        if (!empty($clean_id)) {
            $order = wc_get_order((int) $clean_id);
        }

        if (!$order) {
            $orders = wc_get_orders([
                'meta_query' => [
                    'relation' => 'OR',
                    ['key' => '_steadfast_consignment_id', 'value' => $barcode, 'compare' => '='],
                    ['key' => '_courier_code', 'value' => $barcode, 'compare' => '='],
                ],
                'limit' => 1,
            ]);
            if (!empty($orders)) {
                $order = $orders[0];
            }
        }

        if (!$order) {
            return $this->json_error("অর্ডার নম্বর '$barcode' খুঁজে পাওয়া যায়নি।", 'not_found', 404);
        }

        $order_id = $order->get_id();
        $formatted_now = wp_date('d M Y, h:i A');
        $status = $order->get_status();

        if ($status === 'cancelled') {
            return $this->json_error("অর্ডারটি বাতিল (Cancelled) করা হয়েছে। স্ক্যান গ্রহণযোগ্য নয়।", 'order_cancelled', 400);
        }
        if ($status === 'completed') {
            return $this->json_error("অর্ডারটি ইতোমধ্যে কাস্টমারকে ডেলিভার করা হয়েছে।", 'already_delivered', 400);
        }
        $payment_status = $order->get_meta('_gb_payment_status');
        if ($payment_status === 'rejected') {
            return $this->json_error("অর্ডারটির পেমেন্ট রিজেক্টেড। ভেরিফাই না হওয়া পর্যন্ত স্ক্যান করা যাবে না।", 'payment_rejected', 400);
        }

        $hub = sanitize_text_field($params['hub'] ?? $params['warehouse'] ?? '');

        if ($action === 'dispatch_kl_to_dhaka') {
            if ($hub === 'dhaka_hub') {
                return $this->json_error("লোকেশন ত্রুটি: ঢাকা হাব থেকে কুয়ালালামপুর ডিসপ্যাচ স্ক্যান করা যাবে না।", 'invalid_warehouse_action', 403);
            }
            update_post_meta($order_id, '_gb_tracking_stage', 3);
            update_post_meta($order_id, '_gb_fulfillment_stage', 'malaysia_dispatch');
            update_post_meta($order_id, '_gb_kl_dispatch_time', $formatted_now);
            $order->update_status('wc-in-transit', "[Staff Barcode Scan] কুয়ালালামপুর থেকে ঢাকায় পাঠানো হয়েছে (KL Hub: $formatted_now). $notes");
            $order->save();

            return $this->json_success([
                'order_id'  => $order_id,
                'stage'     => 3,
                'action'    => $action,
                'message'   => 'কুয়ালালামপুর থেকে পাঠানো হয়েছে',
                'timestamp' => $formatted_now,
            ], 'কুয়ালালামপুর থেকে পাঠানো হয়েছে');
        } elseif ($action === 'arrive_dhaka') {
            if ($hub === 'kl_hub') {
                return $this->json_error("লোকেশন ত্রুটি: কুয়ালালামপুর হাব থেকে ঢাকা অ্যারাইভাল স্ক্যান করা যাবে না।", 'invalid_warehouse_action', 403);
            }
            $current_stage = (int) get_post_meta($order_id, '_gb_tracking_stage', true);
            if ($current_stage < 3 && !in_array($status, ['wc-in-transit', 'shipped'])) {
                return $this->json_error("অর্ডারটি এখনও মালয়েশিয়া থেকে পাঠানো হয়নি। ঢাকা অ্যারাইভাল সম্ভব নয়।", 'not_in_transit', 400);
            }
            if ($current_stage >= 4) {
                return $this->json_error("পার্সেলটি ইতোমধ্যে ঢাকা হাবে রিসিভ করা হয়েছে (ডুপ্লিকেট স্ক্যান)।", 'duplicate_scan', 400);
            }
            update_post_meta($order_id, '_gb_tracking_stage', 4);
            update_post_meta($order_id, '_gb_fulfillment_stage', 'arrived_dhaka');
            update_post_meta($order_id, '_gb_dhaka_arrive_time', $formatted_now);
            $order->update_status('wc-arrived-dhaka', "[Staff Barcode Scan] ঢাকা হাবে রিসিভ করা হয়েছে (Dhaka Hub: $formatted_now). $notes");
            $order->save();

            return $this->json_success([
                'order_id'  => $order_id,
                'stage'     => 4,
                'action'    => $action,
                'message'   => 'ঢাকা হাবে রিসিভ করা হয়েছে',
                'timestamp' => $formatted_now,
            ], 'ঢাকা হাবে রিসিভ করা হয়েছে');
        } else {
            return $this->json_error("অজানা অ্যাকশন: '$action'। সমর্থিত অ্যাকশন: dispatch_kl_to_dhaka, arrive_dhaka", 'invalid_action', 400);
        }
    }

    /**
     * Generate secure HMAC-SHA256 authenticated token
     */
    public function generate_auth_token($user_id) {
        $user = get_userdata($user_id);
        if (!$user) return '';
        $issued_at = time();
        $expires_at = $issued_at + (30 * DAY_IN_SECONDS); // 30 days
        $payload = base64_encode(json_encode([
            'uid' => $user->ID,
            'em'  => $user->user_email,
            'iat' => $issued_at,
            'exp' => $expires_at,
        ]));
        $secret = defined('AUTH_KEY') ? AUTH_KEY : 'gb_secure_secret_key_2026';
        $signature = hash_hmac('sha256', $payload, $secret);
        return $payload . '.' . $signature;
    }

    /**
     * Validate auth token from Request Header or param
     * Returns WP_User or WP_Error
     */
    public function validate_auth_token(WP_REST_Request $request) {
        $auth_header = $request->get_header('Authorization');
        $token = '';
        if ($auth_header && preg_match('/Bearer\s+(\S+)/i', $auth_header, $matches)) {
            $token = $matches[1];
        } else {
            $token = $request->get_param('token') ?: $request->get_param('auth_token');
        }

        if (empty($token)) {
            // Backward compatibility fallback for transitional requests if valid user_id is provided
            $user_id = (int) $request->get_param('user_id');
            if ($user_id > 0) {
                $u = get_userdata($user_id);
                if ($u) return $u;
            }
            return new WP_Error('unauthorized', 'Authentication token is required.', ['status' => 401]);
        }

        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            return new WP_Error('invalid_token', 'Invalid token structure.', ['status' => 401]);
        }

        list($payload_b64, $signature) = $parts;
        $secret = defined('AUTH_KEY') ? AUTH_KEY : 'gb_secure_secret_key_2026';
        $expected = hash_hmac('sha256', $payload_b64, $secret);

        if (!hash_equals($expected, $signature)) {
            return new WP_Error('invalid_signature', 'Token signature mismatch.', ['status' => 401]);
        }

        $payload = json_decode(base64_decode($payload_b64), true);
        if (!$payload || !isset($payload['uid']) || !isset($payload['exp'])) {
            return new WP_Error('malformed_token', 'Malformed token payload.', ['status' => 401]);
        }

        if (time() > $payload['exp']) {
            return new WP_Error('token_expired', 'Token has expired. Please log in again.', ['status' => 401]);
        }

        $user = get_userdata($payload['uid']);
        if (!$user) {
            return new WP_Error('user_not_found', 'User associated with token not found.', ['status' => 404]);
        }

        return $user;
    }

    /**
     * REST Permission Callback for authenticated user routes
     */
    public function require_auth_permission(WP_REST_Request $request) {
        $res = $this->validate_auth_token($request);
        return !is_wp_error($res);
    }

    /**
     * 9. Auth: Login
     */
    public function auth_login(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $username = sanitize_user($params['username'] ?? '');
        $password = $params['password'] ?? '';

        if (empty($username) || empty($password)) {
            return $this->json_error('Username and password are required.', 'missing_fields', 400);
        }

        $user = wp_authenticate($username, $password);
        if (is_wp_error($user)) {
            return $this->json_error('Invalid email or password. Please try again.', 'invalid_credentials', 401);
        }

        return $this->json_success([
            'id'           => $user->ID,
            'name'         => $user->display_name ?: $user->user_login,
            'email'        => $user->user_email,
            'phone'        => get_user_meta($user->ID, 'billing_phone', true) ?: '',
            'avatar'       => get_avatar_url($user->ID),
            'token'        => $this->generate_auth_token($user->ID),
            'member_tier'  => 'Glow VIP Member',
            'roles'        => (array) $user->roles,
        ], 'Login successful');
    }

    /**
     * 10. Auth: Register
     */
    public function auth_register(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $name     = sanitize_text_field($params['name'] ?? '');
        $email    = sanitize_email($params['email'] ?? '');
        $phone    = sanitize_text_field($params['phone'] ?? '');
        $password = $params['password'] ?? '';

        if (empty($email) || empty($password)) {
            return $this->json_error('Email and password are required.', 'missing_fields', 400);
        }

        if (email_exists($email)) {
            return $this->json_error('An account already exists with this email address.', 'email_exists', 400);
        }

        $username = sanitize_user(explode('@', $email)[0]);
        $base_username = $username;
        $i = 1;
        while (username_exists($username)) {
            $username = $base_username . $i++;
        }

        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            return $this->json_error($user_id->get_error_message(), 'registration_failed', 500);
        }

        wp_update_user([
            'ID'           => $user_id,
            'display_name' => $name ?: $username,
        ]);

        if (!empty($phone)) {
            update_user_meta($user_id, 'billing_phone', $phone);
        }

        return $this->json_success([
            'id'           => $user_id,
            'name'         => $name ?: $username,
            'email'        => $email,
            'phone'        => $phone,
            'avatar'       => get_avatar_url($user_id),
            'token'        => $this->generate_auth_token($user_id),
            'member_tier'  => 'Glow Member',
        ], 'Account created successfully');
    }

    /**
     * 11. Auth: Social Login
     */
    public function auth_social_login(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $email = sanitize_email($params['email'] ?? '');
        $name = sanitize_text_field($params['name'] ?? '');
        $avatar = esc_url_raw($params['avatar'] ?? '');

        if (empty($email)) {
            return $this->json_error('Email is required for social authentication.', 'missing_email', 400);
        }

        $user = get_user_by('email', $email);
        if (!$user) {
            $username = sanitize_user(explode('@', $email)[0]);
            $random_pw = wp_generate_password(16, true);
            $user_id = wp_create_user($username, $random_pw, $email);
            if (is_wp_error($user_id)) {
                return $this->json_error($user_id->get_error_message(), 'social_create_failed', 500);
            }
            wp_update_user(['ID' => $user_id, 'display_name' => $name ?: $username]);
            $user = get_user_by('id', $user_id);
        }

        return $this->json_success([
            'id'          => $user->ID,
            'name'        => $user->display_name ?: $name,
            'email'       => $user->user_email,
            'phone'       => get_user_meta($user->ID, 'billing_phone', true) ?: '',
            'avatar'      => $avatar ?: get_avatar_url($user->ID),
            'token'       => $this->generate_auth_token($user->ID),
            'member_tier' => 'Glow Member',
        ], 'Social authentication successful');
    }

    /**
     * 11.1 Auth: Forgot Password
     */
    public function auth_forgot_password(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $user_login = sanitize_text_field($params['user_login'] ?? '');

        if (empty($user_login)) {
            return $this->json_error('Please provide your email address.', 'missing_email', 400);
        }

        $user = get_user_by('email', $user_login);
        if (!$user) {
            $user = get_user_by('login', $user_login);
        }

        if (!$user) {
            return $this->json_success([], 'If an account exists with this email, a password reset link has been sent.');
        }

        require_once ABSPATH . WPINC . '/pluggable.php';
        $result = retrieve_password($user->user_login);
        if (is_wp_error($result)) {
            return $this->json_error($result->get_error_message(), 'reset_failed', 500);
        }

        return $this->json_success([], 'Password reset link has been sent to your email.');
    }

    /**
     * 12. User Dashboard
     */
    public function get_user_dashboard(WP_REST_Request $request) {
        $auth_user = $this->validate_auth_token($request);
        if (is_wp_error($auth_user)) {
            return $this->json_error($auth_user->get_error_message(), $auth_user->get_error_code(), 401);
        }
        $user_id = $auth_user->ID;
        $user = $auth_user;

        $order_count = 0;
        $total_spent = 0;
        $funnel = [
            'to_pay'     => 0,
            'to_ship'    => 0,
            'shipped'    => 0,
            'delivered'  => 0,
            'returns'    => 0,
            'in_transit' => 0,
            'to_review'  => 0,
        ];
        $recent_orders = [];

        if ($user_id > 0 && function_exists('wc_get_orders')) {
            $orders = wc_get_orders([
                'customer_id' => $user_id,
                'limit'       => -1,
                'status'      => array('pending','on-hold','checkout-draft','wc-to-pay','processing','wc-to-ship','wc-payment-review','wc-kl-processing','shipped','wc-in-transit','wc-arrived-dhaka','wc-in-flight','wc-dhaka-hub','wc-with-courier','completed','refunded','cancelled','failed','wc-return-review'),
                'orderby'     => 'date',
                'order'       => 'DESC',
            ]);
            $order_count = count($orders);
            foreach ($orders as $o) {
                $total_spent += (float) $o->get_total();
                $st = $o->get_status();
                if (in_array($st, ['pending', 'on-hold', 'checkout-draft', 'wc-to-pay'])) {
                    $funnel['to_pay']++;
                } elseif (in_array($st, ['processing', 'wc-to-ship', 'wc-payment-review', 'wc-kl-processing'])) {
                    $funnel['to_ship']++;
                } elseif (in_array($st, ['shipped', 'wc-in-transit', 'wc-arrived-dhaka', 'wc-in-flight', 'wc-dhaka-hub', 'wc-with-courier'])) {
                    $funnel['shipped']++;
                    $funnel['in_transit']++;
                } elseif ($st === 'completed') {
                    $funnel['delivered']++;
                } elseif (in_array($st, ['refunded', 'cancelled', 'failed', 'wc-return-review'])) {
                    $funnel['returns']++;
                }
            }

            // Top recent orders with strict funnel classification
            foreach (array_slice($orders, 0, 10) as $o) {
                $raw_st = $o->get_status();
                $funnel_cat = 'to_pay';
                if (in_array($raw_st, ['refunded', 'cancelled', 'failed', 'wc-return-review'])) {
                    $funnel_cat = 'returns';
                } elseif ($raw_st === 'completed') {
                    $funnel_cat = 'delivered';
                } elseif (in_array($raw_st, ['shipped', 'wc-in-transit', 'wc-arrived-dhaka', 'wc-in-flight', 'wc-dhaka-hub', 'wc-with-courier'])) {
                    $funnel_cat = 'in_transit';
                } elseif (in_array($raw_st, ['processing', 'wc-to-ship', 'wc-payment-review', 'wc-kl-processing'])) {
                    $funnel_cat = 'to_ship';
                }

                $recent_orders[] = [
                    'id'              => $o->get_id(),
                    'number'          => $o->get_order_number(),
                    'total'           => '৳' . number_format($o->get_total(), 0),
                    'status'          => wc_get_order_status_name($raw_st),
                    'raw_status'      => $raw_st,
                    'funnel_category' => $funnel_cat,
                    'is_cancelled'    => in_array($raw_st, ['cancelled', 'failed']),
                    'is_refunded'     => ($raw_st === 'refunded'),
                    'date'            => $o->get_date_created() ? $o->get_date_created()->date('d M Y') : '',
                ];
            }
        }

        $glow_coins = (int) get_user_meta($user_id, '_gb_glow_coins', true) ?: (int) get_user_meta($user_id, '_gb_glowcoins_balance', true);
        $reward_points = (int) ($total_spent * 0.1);
        $wishlist_count = class_exists('GB_Wishlist_Engine') ? GB_Wishlist_Engine::count() : 0;

        $tier_info = $this->calculate_customer_tier($total_spent, $order_count);

        return $this->json_success([
            'profile' => [
                'id'           => $user->ID,
                'name'         => trim($user->first_name . ' ' . $user->last_name) ?: $user->display_name,
                'email'        => $user->user_email,
                'phone'        => get_user_meta($user_id, 'billing_phone', true) ?: (get_user_meta($user_id, 'phone', true) ?: ''),
                'avatar_url'   => get_avatar_url($user_id, ['size' => 96]),
                'date_created' => $user->user_registered,
                'vip_tier'     => $tier_info['label'],
            ],
            'wallet' => [
                'glow_coins'            => $glow_coins,
                'reward_points'         => $reward_points,
                'active_vouchers'       => function_exists('wp_count_posts') ? (int) wp_count_posts('shop_coupon')->publish : 0,
                'total_spent'           => $total_spent,
                'total_spent_formatted' => '৳' . number_format($total_spent, 0),
            ],
            'orders_funnel'  => $funnel,
            'total_orders'   => $order_count,
            'recent_orders'  => $recent_orders,
            'orders_count'   => $order_count,
            'wishlist_count' => $wishlist_count,
            'member_badge'   => $tier_info['badge'],
            'tier'           => $tier_info,
        ]);
    }

    /**
     * Calculate dynamic VIP tier based on real WooCommerce order spend & count
     */
    public function calculate_customer_tier($total_spent, $order_count) {
        $total_spent = (float) $total_spent;
        $order_count = (int) $order_count;

        if ($total_spent >= 30000 || $order_count >= 10) {
            return [
                'level'          => 4,
                'tier'           => 'diamond',
                'label'          => 'Diamond VIP',
                'badge'          => '👑 Diamond VIP',
                'color'          => '#F59E0B',
                'discount'       => '10%',
                'min_spent'      => 30000,
                'min_orders'     => 10,
                'next_tier'      => null,
                'next_target'    => 0,
                'progress_ratio' => 1.0,
                'remaining_msg'  => 'Top 1% VIP Shopper • Maximum perks unlocked',
            ];
        } elseif ($total_spent >= 15000 || $order_count >= 6) {
            $needed_spent = max(0, 30000 - $total_spent);
            $needed_orders = max(0, 10 - $order_count);
            $ratio = min(1.0, max(0.0, ($total_spent - 15000) / 15000));
            return [
                'level'          => 3,
                'tier'           => 'platinum',
                'label'          => 'Platinum Member',
                'badge'          => '💎 Platinum Member',
                'color'          => '#8B5CF6',
                'discount'       => '7%',
                'min_spent'      => 15000,
                'min_orders'     => 6,
                'next_tier'      => 'Diamond VIP',
                'next_target'    => 30000,
                'progress_ratio' => $ratio,
                'remaining_msg'  => 'Spend ৳' . number_format($needed_spent, 0) . ' or ' . $needed_orders . ' more orders for Diamond VIP',
            ];
        } elseif ($total_spent >= 5000 || $order_count >= 2) {
            $needed_spent = max(0, 15000 - $total_spent);
            $needed_orders = max(0, 6 - $order_count);
            $ratio = min(1.0, max(0.0, ($total_spent - 5000) / 10000));
            return [
                'level'          => 2,
                'tier'           => 'gold',
                'label'          => 'Gold Member',
                'badge'          => '✨ Gold Member',
                'color'          => '#EAB308',
                'discount'       => '5%',
                'min_spent'      => 5000,
                'min_orders'     => 2,
                'next_tier'      => 'Platinum Member',
                'next_target'    => 15000,
                'progress_ratio' => $ratio,
                'remaining_msg'  => 'Spend ৳' . number_format($needed_spent, 0) . ' or ' . $needed_orders . ' more orders for Platinum',
            ];
        } else {
            $needed_spent = max(0, 5000 - $total_spent);
            $needed_orders = max(0, 2 - $order_count);
            $ratio = min(1.0, max(0.0, $total_spent / 5000));
            return [
                'level'          => 1,
                'tier'           => 'silver',
                'label'          => 'Silver Member',
                'badge'          => '🌱 Silver Member',
                'color'          => '#64748B',
                'discount'       => '0%',
                'min_spent'      => 0,
                'min_orders'     => 0,
                'next_tier'      => 'Gold Member',
                'next_target'    => 5000,
                'progress_ratio' => $ratio,
                'remaining_msg'  => 'Spend ৳' . number_format($needed_spent, 0) . ' or ' . $needed_orders . ' more orders for Gold',
            ];
        }
    }

    /**
     * 13. User Orders
     */
    public function get_user_orders(WP_REST_Request $request) {
        $auth_user = $this->validate_auth_token($request);
        if (is_wp_error($auth_user)) {
            return $this->json_error($auth_user->get_error_message(), $auth_user->get_error_code(), 401);
        }
        $user_id = $auth_user->ID;
        $results = [];

        if ($user_id > 0 && function_exists('wc_get_orders')) {
            $orders = wc_get_orders([
                'customer' => $user_id,
                'limit'    => 20,
                'orderby'  => 'date',
                'order'    => 'DESC',
            ]);
            foreach ($orders as $o) {
                $items = [];
                foreach ($o->get_items() as $item) {
                    $product = $item->get_product();
                    $items[] = [
                        'name'     => $item->get_name(),
                        'quantity' => $item->get_quantity(),
                        'total'    => (float) $item->get_total(),
                        'image'    => $product ? wp_get_attachment_url($product->get_image_id()) : '',
                    ];
                }
                $results[] = [
                    'id'           => $o->get_id(),
                    'status'       => $o->get_status(),
                    'total'        => (float) $o->get_total(),
                    'currency'     => '৳',
                    'date_created' => $o->get_date_created() ? $o->get_date_created()->date('Y-m-d') : '',
                    'items'        => $items,
                ];
            }
        }

        return $this->json_success($results);
    }

    /**
     * 14. User Addresses
     */
    public function handle_user_addresses(WP_REST_Request $request) {
        $auth_user = $this->validate_auth_token($request);
        if (is_wp_error($auth_user)) {
            return $this->json_error($auth_user->get_error_message(), $auth_user->get_error_code(), 401);
        }
        $user_id = $auth_user->ID;

        if ($request->get_method() === 'POST') {
            $params = $request->get_json_params() ?: [];
            if ($user_id > 0) {
                update_user_meta($user_id, '_glowbay_saved_addresses', $params);
            }
            return $this->json_success($params, 'Address updated successfully');
        }

        $saved = ($user_id > 0) ? get_user_meta($user_id, '_glowbay_saved_addresses', true) : [];
        return $this->json_success(is_array($saved) ? $saved : []);
    }

    /**
     * 15. Vouchers / Coupons
     */
    public function get_vouchers(WP_REST_Request $request) {
        $vouchers = [];

        if (class_exists('WC_Coupon')) {
            $coupons = get_posts([
                'post_type'      => 'shop_coupon',
                'post_status'    => 'publish',
                'posts_per_page' => 10,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);

            foreach ($coupons as $c) {
                $wc = new WC_Coupon($c->post_title);
                if (!$wc->get_id()) continue;

                if ($wc->get_date_expires() && $wc->get_date_expires()->getTimestamp() < time()) {
                    continue; // Skip expired
                }

                $type = $wc->get_discount_type();
                $amt = (float)$wc->get_amount();
                $discount_str = ($type === 'percent') ? "{$amt}% OFF" : "৳ " . number_format($amt, 0) . " OFF";
                if ($wc->get_free_shipping()) {
                    $discount_str = 'Free Shipping';
                }

                $min_spend = (float)$wc->get_minimum_amount();
                $min_spend_str = ($min_spend > 0) ? "Min Spend ৳" . number_format($min_spend, 0) : "No Min Spend";

                $vouchers[] = [
                    'code'        => strtoupper($wc->get_code()),
                    'discount'    => $discount_str,
                    'description' => $c->post_excerpt ?: ($c->post_title . ' exclusive voucher'),
                    'expiry'      => $wc->get_date_expires() ? 'Expires ' . $wc->get_date_expires()->date('d M Y') : 'Valid for limited time',
                    'min_spend'   => $min_spend_str,
                ];
            }
        }

        // Fallback default official vouchers if no coupons published yet
        if (empty($vouchers)) {
            $vouchers = [
                [
                    'code'        => 'GLOW5',
                    'discount'    => '5% OFF',
                    'description' => 'Welcome gift on your first Malaysian beauty order.',
                    'expiry'      => 'Valid for this month',
                    'min_spend'   => 'No Min Spend',
                ],
                [
                    'code'        => 'FREESHIP',
                    'discount'    => 'Free Shipping',
                    'description' => 'Free delivery on orders over ৳3,000.',
                    'expiry'      => 'Limited Time',
                    'min_spend'   => 'Min Spend ৳ 3,000',
                ],
            ];
        }

        return $this->json_success($vouchers);
    }

    /**
     * 19. Validate Coupon in Cart / Checkout
     */
    public function validate_coupon(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $code = sanitize_text_field($params['code'] ?? '');
        $subtotal = (float)($params['subtotal'] ?? 0);

        if (empty($code)) {
            return $this->json_error('Please enter a coupon code.', 'invalid_code', 400);
        }

        $clean_code = strtolower(trim($code));

        if (!class_exists('WC_Coupon')) {
            if ($clean_code === 'glow5') {
                $discount = round($subtotal * 0.05);
                return $this->json_success([
                    'code'          => 'GLOW5',
                    'discount'      => $discount,
                    'free_shipping' => false,
                    'message'       => 'Coupon GLOW5 applied! 5% discount added.',
                ]);
            }
            if ($clean_code === 'freeship') {
                if ($subtotal < 3000) {
                    return $this->json_error('Minimum spend for FREESHIP is ৳3,000.', 'min_spend_not_met', 400);
                }
                return $this->json_success([
                    'code'          => 'FREESHIP',
                    'discount'      => 0,
                    'free_shipping' => true,
                    'message'       => 'Coupon FREESHIP applied! Free delivery unlocked.',
                ]);
            }
            return $this->json_error('Invalid coupon code.', 'not_found', 404);
        }

        $coupon = new WC_Coupon($clean_code);
        if (!$coupon->get_id()) {
            if ($clean_code === 'glow5') {
                $discount = round($subtotal * 0.05);
                return $this->json_success([
                    'code'          => 'GLOW5',
                    'discount'      => $discount,
                    'free_shipping' => false,
                    'message'       => 'Coupon GLOW5 applied! 5% discount added.',
                ]);
            }
            if ($clean_code === 'freeship') {
                if ($subtotal < 3000) {
                    return $this->json_error('Minimum spend for FREESHIP is ৳3,000.', 'min_spend_not_met', 400);
                }
                return $this->json_success([
                    'code'          => 'FREESHIP',
                    'discount'      => 0,
                    'free_shipping' => true,
                    'message'       => 'Coupon FREESHIP applied! Free delivery unlocked.',
                ]);
            }
            return $this->json_error('Coupon "' . esc_html($code) . '" does not exist.', 'invalid_coupon', 404);
        }

        // Check expiration
        if ($coupon->get_date_expires() && $coupon->get_date_expires()->getTimestamp() < time()) {
            return $this->json_error('This coupon has expired.', 'coupon_expired', 400);
        }

        // Check minimum spend
        $min_spend = (float) $coupon->get_minimum_amount();
        if ($min_spend > 0 && $subtotal < $min_spend) {
            return $this->json_error('Minimum spend for this coupon is ৳' . number_format($min_spend, 0) . '.', 'min_spend_not_met', 400);
        }

        // Check maximum spend
        $max_spend = (float) $coupon->get_maximum_amount();
        if ($max_spend > 0 && $subtotal > $max_spend) {
            return $this->json_error('Maximum spend for this coupon is ৳' . number_format($max_spend, 0) . '.', 'max_spend_exceeded', 400);
        }

        // Calculate discount
        $discount = 0.0;
        $type = $coupon->get_discount_type();
        $amount = (float) $coupon->get_amount();

        if ($type === 'percent') {
            $discount = round(($subtotal * ($amount / 100)));
        } else {
            $discount = min($amount, $subtotal);
        }

        $free_shipping = (bool) $coupon->get_free_shipping();

        return $this->json_success([
            'code'          => strtoupper($coupon->get_code()),
            'discount'      => (float) $discount,
            'free_shipping' => $free_shipping,
            'discount_type' => $type,
            'message'       => 'Coupon ' . strtoupper($coupon->get_code()) . ' applied successfully!',
        ]);
    }

    /**
     * 20. Verified Customer Reviews
     */
    public function get_verified_reviews(WP_REST_Request $request) {
        $reviews = [];

        $comments = get_comments([
            'post_type' => 'product',
            'status'    => 'approve',
            'number'    => 10,
        ]);

        foreach ($comments as $c) {
            $rating = (int) get_comment_meta($c->comment_ID, 'rating', true) ?: 5;
            $prod = wc_get_product($c->comment_post_ID);
            $reviews[] = [
                'id'           => (int)$c->comment_ID,
                'author'       => $c->comment_author,
                'rating'       => $rating,
                'content'      => wp_strip_all_tags($c->comment_content),
                'date'         => mysql2date('d M Y', $c->comment_date),
                'product_name' => $prod ? $prod->get_name() : 'Authentic Malaysian Skincare',
                'verified'     => true,
            ];
        }

        if (empty($reviews)) {
            $reviews = [
                [
                    'id'           => 1,
                    'author'       => 'Farzana Haque',
                    'rating'       => 5,
                    'content'      => '100% genuine CeraVe cleanser! Malaysian packaging with batch code. Delivered safely in 12 days.',
                    'date'         => '10 Aug 2026',
                    'product_name' => 'CeraVe Hydrating Cleanser 473ml',
                    'verified'     => true,
                ],
                [
                    'id'           => 2,
                    'author'       => 'Shahriar Kabir',
                    'rating'       => 5,
                    'content'      => 'Best service for authentic COSRX essence. 50% advance system is very safe and reliable.',
                    'date'         => '04 Sep 2026',
                    'product_name' => 'Cosrx Advanced Snail 92 All in One Cream',
                    'verified'     => true,
                ],
                [
                    'id'           => 3,
                    'author'       => 'Tasmia Jahan',
                    'rating'       => 5,
                    'content'      => 'Blackmores multivitamins arrived fresh with QR seal. Highly recommend for authentic Malaysian imports.',
                    'date'         => '01 Sep 2026',
                    'product_name' => 'Blackmores Multivitamins 120 Tablets',
                    'verified'     => true,
                ],
            ];
        }

        return $this->json_success($reviews);
    }

    /**
     * 16. Product Sourcing Request
     */
    public function submit_product_request(WP_REST_Request $request) {
        $params = $request->get_json_params() ?: [];
        $name  = sanitize_text_field($params['product_name'] ?? '');
        $brand = sanitize_text_field($params['brand'] ?? '');
        $phone = sanitize_text_field($params['phone'] ?? '');
        $notes = sanitize_textarea_field($params['notes'] ?? '');

        if (empty($name) || empty($phone)) {
            return $this->json_error('Product name and contact phone number are required.', 'missing_fields', 400);
        }

        // Save as WordPress option / custom post / email alert
        $requests = get_option('_glowbay_product_requests', []);
        $requests[] = [
            'product_name' => $name,
            'brand'        => $brand,
            'phone'        => $phone,
            'notes'        => $notes,
            'created_at'   => current_time('mysql'),
        ];
        update_option('_glowbay_product_requests', array_slice($requests, -100));

        return $this->json_success(null, 'Product request submitted! Our Malaysia sourcing team will contact you shortly.');
    }

    /**
     * 17. Affiliate Stats
     */
    public function get_affiliate_stats(WP_REST_Request $request) {
        global $wpdb;
        $user_id = get_current_user_id();
        $code_param = sanitize_text_field($request->get_param('code'));
        $email_param = sanitize_email($request->get_param('email'));
        
        $applicant = null;
        if ($user_id > 0) {
            $applicant = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gbaff_applicants WHERE user_id = %d LIMIT 1",
                $user_id
            ));
        }
        if (!$applicant && !empty($code_param)) {
            $applicant = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gbaff_applicants WHERE code = %s LIMIT 1",
                $code_param
            ));
        }
        if (!$applicant && !empty($email_param)) {
            $applicant = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gbaff_applicants WHERE email = %s LIMIT 1",
                $email_param
            ));
        }

        if (!$applicant) {
            return $this->json_success([
                'status'          => 'none',
                'is_affiliate'    => false,
                'message'         => 'No affiliate account found for this user.',
                'apply_url'       => home_url('/affiliate/'),
            ]);
        }

        if ($applicant->status !== 'approved') {
            return $this->json_success([
                'status'          => $applicant->status,
                'is_affiliate'    => false,
                'name'            => $applicant->name,
                'email'           => $applicant->email,
                'code'            => $applicant->code,
                'message'         => $applicant->status === 'pending' ? 'Your affiliate application is currently pending review.' : 'Your affiliate application was rejected.',
            ]);
        }

        $aff_id = (int)$applicant->id;
        $code = $applicant->code;

        $total_clicks = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gbaff_visits WHERE affiliate_id = %d",
            $aff_id
        ));

        $total_orders = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gbaff_referrals WHERE affiliate_id = %d AND status != 'cancelled'",
            $aff_id
        ));

        $total_earnings = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(commission), 0) FROM {$wpdb->prefix}gbaff_referrals WHERE affiliate_id = %d AND status IN ('completed', 'approved', 'confirmed')",
            $aff_id
        ));

        $pending_earnings = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(commission), 0) FROM {$wpdb->prefix}gbaff_referrals WHERE affiliate_id = %d AND status = 'pending'",
            $aff_id
        ));

        $paid_payouts = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM {$wpdb->prefix}gbaff_payouts WHERE affiliate_id = %d AND status = 'paid'",
            $aff_id
        ));

        $pending_payouts = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM {$wpdb->prefix}gbaff_payouts WHERE affiliate_id = %d AND status = 'pending'",
            $aff_id
        ));

        $available_balance = max(0, $total_earnings - ($paid_payouts + $pending_payouts));
        $global_rate = get_option('gbaff_commission_rate', '10');
        $rate_val = !empty($applicant->commission_rate) ? $applicant->commission_rate : $global_rate;
        $rate_str = $rate_val . '% per sale';

        return $this->json_success([
            'status'            => 'approved',
            'is_affiliate'      => true,
            'affiliate_id'      => $aff_id,
            'name'              => $applicant->name,
            'referral_code'     => $code,
            'referral_link'     => home_url('/?ref=' . $code),
            'total_clicks'      => $total_clicks,
            'total_orders'      => $total_orders,
            'total_earnings'    => $total_earnings,
            'available_balance' => $available_balance,
            'pending_payout'    => $pending_payouts,
            'pending_earnings'  => $pending_earnings,
            'commission_rate'   => $rate_str,
            'dashboard_url'     => home_url('/affiliate-dashboard/'),
        ]);
    }

    /**
     * 18. Payment Methods Configuration & Gateway Details
     */
    public function get_payment_methods(WP_REST_Request $request) {
        // Safe standard defaults
        $bkash_number = '01624810710';
        $bkash_type   = 'Personal';
        $nagad_number = '01624810710';
        $nagad_type   = 'Personal';
        $bank_name    = 'Islami Bank Bangladesh PLC';
        $account_name = 'Akher Hossan';
        $account_no   = '20501510202364747';
        $branch_name  = 'আমিন বাজার, ঢাকা (Amin Bazar, Dhaka)';

        // 1. Direct GlowBay Payments plugin settings (WooCommerce options)
        $gb_bank_settings = get_option('woocommerce_glowbay_bank_settings', array());
        if (!empty($gb_bank_settings['account_number'])) {
            $account_no = (string) $gb_bank_settings['account_number'];
        }
        if (!empty($gb_bank_settings['account_name'])) {
            $account_name = (string) $gb_bank_settings['account_name'];
        }
        if (!empty($gb_bank_settings['bank_name'])) {
            $bank_name = (string) $gb_bank_settings['bank_name'];
        }
        if (!empty($gb_bank_settings['branch_name'])) {
            $branch_name = (string) $gb_bank_settings['branch_name'];
        }

        $gb_bkash_settings = get_option('woocommerce_glowbay_bkash_settings', array());
        if (!empty($gb_bkash_settings['bkash_number'])) {
            $bkash_number = (string) $gb_bkash_settings['bkash_number'];
        } elseif (!empty($gb_bkash_settings['number'])) {
            $bkash_number = (string) $gb_bkash_settings['number'];
        }
        if (!empty($gb_bkash_settings['account_type'])) {
            $bkash_type = ucfirst((string) $gb_bkash_settings['account_type']);
        }

        $gb_nagad_settings = get_option('woocommerce_glowbay_nagad_settings', array());
        if (!empty($gb_nagad_settings['nagad_number'])) {
            $nagad_number = (string) $gb_nagad_settings['nagad_number'];
        } elseif (!empty($gb_nagad_settings['number'])) {
            $nagad_number = (string) $gb_nagad_settings['number'];
        }
        if (!empty($gb_nagad_settings['account_type'])) {
            $nagad_type = ucfirst((string) $gb_nagad_settings['account_type']);
        }

        // 2. Direct WP / general options fallback
        if ($val = get_option('glowbay_bkash_number') ?: get_option('bkash_number') ?: get_option('bkash_account_number')) {
            $bkash_number = (string) $val;
        }
        if ($val = get_option('glowbay_bkash_type') ?: get_option('bkash_account_type')) {
            $bkash_type = ucfirst((string) $val);
        }

        if ($val = get_option('glowbay_nagad_number') ?: get_option('nagad_number') ?: get_option('nagad_account_number')) {
            $nagad_number = (string) $val;
        }
        if ($val = get_option('glowbay_nagad_type') ?: get_option('nagad_account_type')) {
            $nagad_type = ucfirst((string) $val);
        }

        if (empty($account_no)) {
            if ($val = get_option('glowbay_bank_account_no')) {
                if ($val !== 'Provided on order') $account_no = (string) $val;
            }
        }

        // 3. Check WooCommerce active gateways and settings
        if (function_exists('WC') && WC()->payment_gateways()) {
            $gateways = WC()->payment_gateways()->payment_gateways();

            foreach ($gateways as $gateway_id => $gateway) {
                $id = strtolower($gateway_id);
                if (isset($gateway->enabled) && $gateway->enabled !== 'yes') {
                    continue;
                }
                $settings = isset($gateway->settings) ? (array) $gateway->settings : [];

                // bKash gateway plugins
                if (strpos($id, 'bkash') !== false) {
                    $found_num = $settings['number'] ?? $settings['phone'] ?? $settings['bkash_number'] ?? $settings['account_number'] ?? $settings['mobile_no'] ?? null;
                    if (!empty($found_num)) {
                        $bkash_number = (string) $found_num;
                    }
                    $found_type = $settings['type'] ?? $settings['account_type'] ?? null;
                    if (!empty($found_type)) {
                        $bkash_type = ucfirst((string) $found_type);
                    }
                }

                // Nagad gateway plugins
                if (strpos($id, 'nagad') !== false) {
                    $found_num = $settings['number'] ?? $settings['phone'] ?? $settings['nagad_number'] ?? $settings['account_number'] ?? $settings['mobile_no'] ?? null;
                    if (!empty($found_num)) {
                        $nagad_number = (string) $found_num;
                    }
                    $found_type = $settings['type'] ?? $settings['account_type'] ?? null;
                    if (!empty($found_type)) {
                        $nagad_type = ucfirst((string) $found_type);
                    }
                }

                // Direct Bank Transfer
                if ($id === 'glowbay_bank' || $id === 'bacs' || strpos($id, 'bank') !== false) {
                    if (!empty($settings['account_number']) && $settings['account_number'] !== 'Provided on order') {
                        $account_no = (string) $settings['account_number'];
                    }
                    if (!empty($settings['account_name'])) {
                        $account_name = (string) $settings['account_name'];
                    }
                    if (!empty($settings['bank_name']) && $settings['bank_name'] !== 'Bank Transfer') {
                        $bank_name = (string) $settings['bank_name'];
                    }
                    if (!empty($settings['branch_name'])) {
                        $branch_name = (string) $settings['branch_name'];
                    }
                    if (!empty($gateway->account_details) && is_array($gateway->account_details)) {
                        $first_acc = reset($gateway->account_details);
                        if (!empty($first_acc['account_number']) && $first_acc['account_number'] !== 'Provided on order') {
                            $account_no = (string) $first_acc['account_number'];
                        }
                        if (!empty($first_acc['bank_name']) && $first_acc['bank_name'] !== 'Bank Transfer') {
                            $bank_name = (string) $first_acc['bank_name'];
                        }
                        if (!empty($first_acc['account_name'])) {
                            $account_name = (string) $first_acc['account_name'];
                        }
                        if (!empty($first_acc['sort_code'])) {
                            $branch_name = (string) $first_acc['sort_code'];
                        }
                    }
                }
            }
        }

        $bqr_settings   = get_option('woocommerce_glowbay_bangla_qr_settings', array());
        $bkash_settings = get_option('woocommerce_glowbay_bkash_settings', array());
        $nagad_settings = get_option('woocommerce_glowbay_nagad_settings', array());

        $bkash_fee_enabled = (($bkash_settings['enable_cashout_fee'] ?? 'yes') === 'yes');
        $bkash_fee_pct     = floatval($bkash_settings['cashout_pct'] ?? 1.5);
        $nagad_fee_enabled = (($nagad_settings['enable_cashout_fee'] ?? 'yes') === 'yes');
        $nagad_fee_pct     = floatval($nagad_settings['cashout_pct'] ?? 1.5);

        $lang = strtolower((string) ($request->get_param('lang') ?? 'en'));
        $is_bn = ($lang === 'bn');

        return $this->json_success([
            'bkash' => [
                'id'                 => 'glowbay_bkash',
                'title'              => $is_bn ? 'বিকাশ (bKash)' : 'bKash',
                'number'             => (string) $bkash_number,
                'type'               => (string) $bkash_type,
                'is_active'          => true,
                'enable_cashout_fee' => $bkash_fee_enabled,
                'cashout_fee_pct'    => $bkash_fee_pct,
                'instruction'        => $is_bn 
                    ? 'আমাদের বিকাশ নম্বরে সেন্ড মানি করুন এবং নিচে TrxID প্রদান করুন।' 
                    : 'Please send money to this bKash number and enter TrxID below.',
            ],
            'nagad' => [
                'id'                 => 'glowbay_nagad',
                'title'              => $is_bn ? 'নগদ (Nagad)' : 'Nagad',
                'number'             => (string) $nagad_number,
                'type'               => (string) $nagad_type,
                'is_active'          => true,
                'enable_cashout_fee' => $nagad_fee_enabled,
                'cashout_fee_pct'    => $nagad_fee_pct,
                'instruction'        => $is_bn 
                    ? 'আমাদের নগদ নম্বরে সেন্ড মানি করুন এবং নিচে TrxID প্রদান করুন।' 
                    : 'Please send money to this Nagad number and enter TrxID below.',
            ],
            'bank' => [
                'id'           => 'glowbay_bank',
                'title'        => $is_bn ? 'ব্যাংক ট্রান্সফার (Bank Transfer)' : 'Bank Transfer',
                'bank_name'    => (string) $bank_name,
                'account_name' => (string) $account_name,
                'account_no'   => (string) $account_no,
                'branch_name'  => (string) $branch_name,
                'is_active'    => true,
                'instruction'  => $is_bn 
                    ? 'উপরে উল্লেখিত ব্যাংক অ্যাকাউন্টে ডিপোজিট বা ট্রান্সফার করে নিচে রসিদের তথ্য প্রদান করুন।' 
                    : 'Please deposit or transfer to the account above and enter receipt details.',
            ],
            'bangla_qr' => [
                'id'             => 'glowbay_bangla_qr',
                'title'          => $is_bn 
                    ? 'বাংলা কিউআর - ইসলামী ব্যাংক (Bangla QR)' 
                    : 'Bangla QR - Islami Bank PLC',
                'bank_name'      => !empty($bqr_settings['bank_name']) ? (string)$bqr_settings['bank_name'] : $bank_name,
                'account_name'   => !empty($bqr_settings['account_name']) ? (string)$bqr_settings['account_name'] : $account_name,
                'account_no'     => !empty($bqr_settings['account_number']) ? (string)$bqr_settings['account_number'] : $account_no,
                'branch_name'    => !empty($bqr_settings['branch_name']) ? (string)$bqr_settings['branch_name'] : $branch_name,
                'merchant_id'    => !empty($bqr_settings['merchant_id']) ? (string)$bqr_settings['merchant_id'] : '',
                'terminal_id'    => !empty($bqr_settings['terminal_id']) ? (string)$bqr_settings['terminal_id'] : '',
                'qr_image_url'   => !empty($bqr_settings['qr_image_url']) ? (string)$bqr_settings['qr_image_url'] : '',
                'is_active'      => (!empty($bqr_settings['enabled']) && $bqr_settings['enabled'] === 'yes'),
                'supported_apps' => ['bKash', 'Nagad', 'Rocket', 'Upay', 'Cellfin', 'VISA', 'Mastercard'],
                'instruction'    => $is_bn 
                    ? 'বিকাশ, নগদ, সেলফিন বা যেকোনো ব্যাংক অ্যাপ দিয়ে কিউআর স্ক্যান করে পেমেন্ট করুন।' 
                    : 'Scan the Bangla QR code using bKash, Nagad, Cellfin or any banking app to pay.',
            ],
            'cod' => [
                'id'          => 'cod',
                'title'       => $is_bn ? 'ক্যাশ অন ডেলিভারি (৫০% অগ্রিম)' : 'Cash on Delivery (50% Advance)',
                'is_active'   => true,
                'instruction' => $is_bn 
                    ? 'অর্ডার কনফার্ম করতে ৫০% অগ্রিম পরিশোধ করুন, বাকি টাকা ডেলিভারিতে।' 
                    : 'Pay remaining balance upon delivery.',
            ],
        ]);
    }

    /**
     * Seamless Live Sync for Website Checkout (Desktop & Mobile)
     * Keeps 100% frontend visual design, but dynamically connects payment
     * account numbers and copy/QR actions with active WooCommerce payment plugin.
     */
    public function sync_live_checkout_payment_numbers() {
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }

        // 1. Fetch dynamic settings
        $bkash_number = '01624810710';
        $bkash_type   = 'Personal';
        $nagad_number = '01624810710';
        $nagad_type   = 'Personal';
        $bank_name    = 'Islami Bank Bangladesh PLC';
        $account_name = 'Akher Hossan';
        $account_no   = '20501510202364747';
        $branch_name  = 'আমিন বাজার, ঢাকা (Amin Bazar, Dhaka)';

        // 0. Direct GlowBay Payments plugin settings (WooCommerce options)
        $gb_bank_settings = get_option('woocommerce_glowbay_bank_settings', array());
        if (!empty($gb_bank_settings['account_number'])) {
            $account_no = (string) $gb_bank_settings['account_number'];
        }
        if (!empty($gb_bank_settings['account_name'])) {
            $account_name = (string) $gb_bank_settings['account_name'];
        }
        if (!empty($gb_bank_settings['bank_name'])) {
            $bank_name = (string) $gb_bank_settings['bank_name'];
        }
        if (!empty($gb_bank_settings['branch_name'])) {
            $branch_name = (string) $gb_bank_settings['branch_name'];
        }

        $gb_bkash_settings = get_option('woocommerce_glowbay_bkash_settings', array());
        if (!empty($gb_bkash_settings['bkash_number'])) {
            $bkash_number = (string) $gb_bkash_settings['bkash_number'];
        } elseif (!empty($gb_bkash_settings['number'])) {
            $bkash_number = (string) $gb_bkash_settings['number'];
        }
        if (!empty($gb_bkash_settings['account_type'])) {
            $bkash_type = ucfirst((string) $gb_bkash_settings['account_type']);
        }

        $gb_nagad_settings = get_option('woocommerce_glowbay_nagad_settings', array());
        if (!empty($gb_nagad_settings['nagad_number'])) {
            $nagad_number = (string) $gb_nagad_settings['nagad_number'];
        } elseif (!empty($gb_nagad_settings['number'])) {
            $nagad_number = (string) $gb_nagad_settings['number'];
        }
        if (!empty($gb_nagad_settings['account_type'])) {
            $nagad_type = ucfirst((string) $gb_nagad_settings['account_type']);
        }

        if ($val = get_option('glowbay_bkash_number') ?: get_option('bkash_number') ?: get_option('bkash_account_number')) {
            $bkash_number = (string) $val;
        }
        if ($val = get_option('glowbay_bkash_type') ?: get_option('bkash_account_type')) {
            $bkash_type = ucfirst((string) $val);
        }
        if ($val = get_option('glowbay_nagad_number') ?: get_option('nagad_number') ?: get_option('nagad_account_number')) {
            $nagad_number = (string) $val;
        }
        if ($val = get_option('glowbay_nagad_type') ?: get_option('nagad_account_type')) {
            $nagad_type = ucfirst((string) $val);
        }
        if (empty($account_no)) {
            if ($val = get_option('glowbay_bank_account_no')) {
                if ($val !== 'Provided on order') $account_no = (string) $val;
            }
        }

        if (function_exists('WC') && WC()->payment_gateways()) {
            $gateways = WC()->payment_gateways()->payment_gateways();
            foreach ($gateways as $gateway_id => $gateway) {
                $id = strtolower($gateway_id);
                if (isset($gateway->enabled) && $gateway->enabled !== 'yes') {
                    continue;
                }
                $settings = isset($gateway->settings) ? (array) $gateway->settings : [];

                if (strpos($id, 'bkash') !== false) {
                    $found_num = $settings['number'] ?? $settings['phone'] ?? $settings['bkash_number'] ?? $settings['account_number'] ?? $settings['mobile_no'] ?? null;
                    if (!empty($found_num)) $bkash_number = (string) $found_num;
                    $found_type = $settings['type'] ?? $settings['account_type'] ?? null;
                    if (!empty($found_type)) $bkash_type = ucfirst((string) $found_type);
                }
                if (strpos($id, 'nagad') !== false) {
                    $found_num = $settings['number'] ?? $settings['phone'] ?? $settings['nagad_number'] ?? $settings['account_number'] ?? $settings['mobile_no'] ?? null;
                    if (!empty($found_num)) $nagad_number = (string) $found_num;
                    $found_type = $settings['type'] ?? $settings['account_type'] ?? null;
                    if (!empty($found_type)) $nagad_type = ucfirst((string) $found_type);
                }
                if ($id === 'glowbay_bank' || $id === 'bacs' || strpos($id, 'bank') !== false) {
                    if (!empty($settings['account_number']) && $settings['account_number'] !== 'Provided on order') {
                        $account_no = (string) $settings['account_number'];
                    }
                    if (!empty($settings['account_name'])) {
                        $account_name = (string) $settings['account_name'];
                    }
                    if (!empty($settings['bank_name']) && $settings['bank_name'] !== 'Bank Transfer') {
                        $bank_name = (string) $settings['bank_name'];
                    }
                    if (!empty($settings['branch_name'])) {
                        $branch_name = (string) $settings['branch_name'];
                    }
                    if (!empty($gateway->account_details) && is_array($gateway->account_details)) {
                        $first_acc = reset($gateway->account_details);
                        if (!empty($first_acc['bank_name'])) $bank_name = (string) $first_acc['bank_name'];
                        if (!empty($first_acc['account_name'])) $account_name = (string) $first_acc['account_name'];
                        if (!empty($first_acc['account_number'])) $account_no = (string) $first_acc['account_number'];
                        if (!empty($first_acc['sort_code'])) $branch_name = (string) $first_acc['sort_code'];
                    }
                }
            }
        }

        $bacs_accounts = get_option('woocommerce_bacs_accounts');
        if (is_array($bacs_accounts) && !empty($bacs_accounts)) {
            $first_bacs = reset($bacs_accounts);
            if (!empty($first_bacs['bank_name'])) $bank_name = (string) $first_bacs['bank_name'];
            if (!empty($first_bacs['account_name'])) $account_name = (string) $first_bacs['account_name'];
            if (!empty($first_bacs['account_number'])) $account_no = (string) $first_bacs['account_number'];
            if (!empty($first_bacs['sort_code'])) $branch_name = (string) $first_bacs['sort_code'];
        }

        $b_num_js = esc_js($bkash_number);
        $n_num_js = esc_js($nagad_number);
        $acc_no_js = esc_js($account_no);
        $acc_name_js = esc_js($account_name);
        $bank_name_js = esc_js($bank_name);
        $branch_js = esc_js($branch_name);
        ?>
        <script type="text/javascript" id="gb-live-payment-sync">
        (function() {
            var liveBkash = '<?php echo $b_num_js; ?>';
            var liveNagad = '<?php echo $n_num_js; ?>';
            var liveBankAcc = '<?php echo $acc_no_js; ?>';
            var liveBankName = '<?php echo $bank_name_js; ?>';
            var liveAccName = '<?php echo $acc_name_js; ?>';
            var liveBranch = '<?php echo $branch_js; ?>';

            function updatePaymentDOM() {
                if (!liveBkash && !liveNagad) return;

                // 1. Desktop & Mobile bKash Numbers
                var bText = document.getElementById('bkashNumText');
                if (bText && liveBkash) {
                    bText.textContent = liveBkash;
                }
                var mobBkash = document.querySelector('#panelBkashDetails .gb-pay-info-left div[style*="font-size:13.5px"]');
                if (mobBkash && liveBkash && mobBkash.childNodes.length > 0) {
                    mobBkash.childNodes[0].nodeValue = liveBkash + ' ';
                }

                // 2. Desktop & Mobile Nagad Numbers
                var nText = document.getElementById('nagadNumText');
                if (nText && liveNagad) {
                    nText.textContent = liveNagad;
                }
                var mobNagad = document.querySelector('#panelNagadDetails .gb-pay-info-left div[style*="font-size:13.5px"]');
                if (mobNagad && liveNagad && mobNagad.childNodes.length > 0) {
                    mobNagad.childNodes[0].nodeValue = liveNagad + ' ';
                }

                // 3. Bank Info
                var bAccStrong = document.querySelector('#panelBankDetails strong[style*="color:#15803D"]');
                if (bAccStrong && liveBankAcc) {
                    bAccStrong.textContent = liveBankAcc;
                }

                // 4. Update Copy Buttons
                document.querySelectorAll('button[onclick*="01624810710"]').forEach(function(btn) {
                    if (btn.closest('#gwBkash') || btn.closest('#detailsBkash') || btn.closest('#panelBkashDetails')) {
                        btn.setAttribute('onclick', "copyText('" + liveBkash + "')");
                    } else if (btn.closest('#gwNagad') || btn.closest('#detailsNagad') || btn.closest('#panelNagadDetails')) {
                        btn.setAttribute('onclick', "copyText('" + liveNagad + "')");
                    }
                });
                document.querySelectorAll('button[onclick*="20501510202364747"]').forEach(function(btn) {
                    btn.setAttribute('onclick', "copyText('" + liveBankAcc + "')");
                });

                // 5. Update QR Code URLs
                var bQr = document.getElementById('bkashQrImg') || document.getElementById('imgBkashQr');
                if (bQr && bQr.src && liveBkash) {
                    bQr.src = bQr.src.replace(/01624810710/g, liveBkash);
                }
                var nQr = document.getElementById('nagadQrImg') || document.getElementById('imgNagadQr');
                if (nQr && nQr.src && liveNagad) {
                    nQr.src = nQr.src.replace(/01624810710/g, liveNagad);
                }

                // 6. Global JS Variables if defined
                if (typeof window.bkashNum !== 'undefined') window.bkashNum = liveBkash;
                if (typeof window.nagadNum !== 'undefined') window.nagadNum = liveNagad;
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', updatePaymentDOM);
            } else {
                updatePaymentDOM();
            }
            setTimeout(updatePaymentDOM, 400);
            setTimeout(updatePaymentDOM, 1200);
        })();
        </script>
        <?php
    }

    /**
     * 21. Register FCM Device Token
     */
    public function register_device_token($request) {
        $token = sanitize_text_field($request->get_param('token'));
        $user_id = absint($request->get_param('user_id'));
        $device_info = sanitize_text_field($request->get_param('device_info'));

        if (empty($token)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Token required'], 400);
        }

        $tokens = get_option('glowbay_fcm_tokens', []);
        $tokens[$token] = [
            'token'       => $token,
            'user_id'     => $user_id,
            'device_info' => $device_info,
            'updated_at'  => current_time('mysql'),
        ];
        update_option('glowbay_fcm_tokens', $tokens);

        if ($user_id > 0) {
            update_user_meta($user_id, 'glowbay_fcm_token', $token);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'FCM Device token registered successfully',
            'token'   => $token,
        ], 200);
    }

    /**
     * 22. Send / Broadcast Notification
     */
    public function broadcast_push_notification($request) {
        $title = sanitize_text_field($request->get_param('title') ?: 'GlowBayBD Alert 🔔');
        $body  = sanitize_text_field($request->get_param('body') ?: 'Check out new authentic skincare arrivals!');
        $topic = sanitize_text_field($request->get_param('topic') ?: 'all_users');

        // Log broadcast request
        $logs = get_option('glowbay_notification_logs', []);
        $logs[] = [
            'title'      => $title,
            'body'       => $body,
            'topic'      => $topic,
            'created_at' => current_time('mysql'),
        ];
        if (count($logs) > 50) {
            $logs = array_slice($logs, -50);
        }
        update_option('glowbay_notification_logs', $logs);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Broadcast queued for topic: ' . $topic,
            'data'    => [
                'title' => $title,
                'body'  => $body,
                'topic' => $topic,
            ],
        ], 200);
    }
}

new GlowBay_App_API();

